import type { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@supabase/supabase-js'
import { requireAuth } from '@/lib/serverAuth'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

// ── සිංහලෙන් ──────────────────────────────────────────────────────────────
// Pick කරගත්ත document එකකට Mail / Download / Look Only කළාම ඒක
// සටහන් කරන තැන. Mail හෝ Download කළාම ඒ වැඩේ ඉවරයි කියලා ගණන් —
// My Picked Tasks එකෙන් අයින් වෙනවා, සහ ඒකට අදාළ ගණන අනුමතයට යනවා
// (doc_approvals). Look Only කිසිම දෙයක් ඉවර කරන්නේ නෑ, බලනවා විතරයි.
// ──────────────────────────────────────────────────────────────────────────
// Logs a 'mail', 'download', or 'look' action against a document — fills out
// the rest of pick_history_log's action set beyond pick/return.
//
// Whichever happens first for a picked document — Mail or Download — also
// auto-resolves that user's "My Picked Tasks" entry for it (marks it
// completed, doesn't re-open the notification to the pool the way a manual
// Return does — mail/download means the work is actually done, not handed
// back). "Look Only" never resolves anything, since it's explicitly a
// no-commitment preview.
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()
  try {
    const authed = await requireAuth(req)
    if (!authed.ok) return res.status(authed.status).json({ error: authed.error })
    const { document_id, action } = req.body as { document_id: string; action: 'mail' | 'download' | 'look' | 'print' }
    if (!document_id || !['mail', 'download', 'look', 'print'].includes(action)) return res.status(400).json({ error: 'document_id and a valid action required' })

    const { data: prof } = await supabaseAdmin.from('profiles').select('username, full_name').eq('id', authed.userId).maybeSingle()
    const userName = prof?.full_name || prof?.username || ''
    await supabaseAdmin.from('pick_history_log').insert({ document_id, user_id: authed.userId, user_name: userName, action })

    // Print counts exactly like Mail/Download — it's a real way of finishing
    // a picked task, not a no-commitment preview like Look Only is.
    if (action === 'mail' || action === 'download' || action === 'print') {
      await supabaseAdmin.from('user_tasks')
        .update({ status: 'completed' })
        .eq('document_id', document_id).eq('user_id', authed.userId).eq('status', 'active')

      // Completing a picked task (Mail/Download) is the SECOND approval
      // stage — the "billing/CAP" count — for both CDN and CUSDEC reasons,
      // separate from the upload-stage approval in document-uploads.ts.
      // Neither stage auto-credits anything; both go through
      // doc-approvals.ts (admin-authorized), so a document's pay can never
      // be double-counted or counted before it's actually been signed off.
      try {
        const { data: doc } = await supabaseAdmin
          .from('document_uploads').select('reason, file_name, doc_type, cusdec_id').eq('id', document_id).maybeSingle()
        if ((doc?.reason === 'Container Moved' && doc?.doc_type === 'cdn') || (doc?.reason === 'CUSDEC Passed' && doc?.doc_type === 'cusdec')) {
          await supabaseAdmin.from('doc_approvals').insert({
            document_id, cusdec_id: doc.cusdec_id || null, doc_type: doc.doc_type, reason: doc.reason,
            uploaded_by: authed.userId, uploaded_by_name: userName, stage: 'billing',
          })
        } else if (doc?.reason === 'Boat Note Passed') {
          // Boat Note Pending's merge-and-pick flow (see dashboard.tsx's
          // confirmPick) had no count of its own at all — folds into
          // neither cdn_inc nor cap_inc. Gated the same way: only counts
          // once mailed/downloaded, and only after admin approval, crediting
          // a dedicated boat_note_inc — one per CUSDEC this merge covered
          // (see boat_note_locks; a merge can span several CUSDECs at once,
          // each with its own cap). A single pick batch produces up to 3
          // separate documents (Boat Note/Party's Copy/CDN merged PDFs),
          // each locking the same CUSDECs under their own document_id — so
          // whichever of the 3 gets Mailed/Downloaded FIRST is the one that
          // credits and releases the lock for that CUSDEC (deleted by
          // cusdec_id, not just this document_id) — the other 2 will find
          // no lock left for it and correctly skip crediting a second/third
          // time for the same CUSDEC.
          const { data: locks } = await supabaseAdmin.from('boat_note_locks').select('cusdec_id').eq('document_id', document_id)

          // A B... Boat Note document picked straight from the Activity Log
          // (uploaded by hand, or created by the Automation tab) never went
          // through the old merge-and-pick flow, so it has NO boat_note_locks
          // row — and this whole branch used to do nothing for it, which is
          // why Mail/Download/Print on a picked B... document never reached
          // the Pick Approvals / Balance. For those, the CUSDEC is found the
          // same way merge-picked-boat-notes.ts does (cusdec_id on the row,
          // otherwise the number in the file name: B55296.pdf -> E 55296),
          // and ONE approval is opened for it — the approval later credits
          // that CUSDEC's own cap (container count) as Boat Cap.
          let noLockCusdecId: string | null = null
          const isBDoc = doc.doc_type === 'boat_note' || /^B\d/i.test(doc.file_name || '')
          if (!locks?.length && isBDoc) {
            noLockCusdecId = doc.cusdec_id || null
            if (!noLockCusdecId) {
              const num = (doc.file_name || '').replace(/\.pdf$/i, '').match(/\d+/)?.[0] || ''
              if (num) {
                const { data: found } = await supabaseAdmin.from('cusdec').select('id, number, created_at').ilike('number', `%${num}%`)
                const matches = (found || []).filter((r: any) => String(r.number || '').replace(/\D/g, '') === num)
                  .sort((a: any, b: any) => String(b.created_at || '').localeCompare(String(a.created_at || '')))
                noLockCusdecId = matches[0]?.id || null
              }
            }
            if (noLockCusdecId) {
              // Same document Mailed then Printed etc. must not open a second approval.
              const { data: already } = await supabaseAdmin.from('doc_approvals').select('id')
                .eq('document_id', document_id).eq('stage', 'boat_note').eq('cusdec_id', noLockCusdecId)
                .in('status', ['pending', 'approved']).limit(1).maybeSingle()
              if (!already) {
                const { error: apErr2 } = await supabaseAdmin.from('doc_approvals').insert({
                  document_id, cusdec_id: noLockCusdecId, doc_type: doc.doc_type || 'boat_note', reason: doc.reason,
                  uploaded_by: authed.userId, uploaded_by_name: userName, stage: 'boat_note',
                })
                if (apErr2) console.error('[log-document-action] boat_note doc_approvals insert failed (no lock):', apErr2.message, apErr2)
              }
            } else {
              console.error('[log-document-action] could not find a CUSDEC for Boat Note document', document_id, doc.file_name)
            }
          }

          if (locks?.length) {
            const cusdecIds = locks.map(l => l.cusdec_id)
            const { error: apErr } = await supabaseAdmin.from('doc_approvals').insert(
              cusdecIds.map(cid => ({
                document_id, cusdec_id: cid, doc_type: doc.doc_type || 'boat_note', reason: doc.reason,
                uploaded_by: authed.userId, uploaded_by_name: userName, stage: 'boat_note',
              }))
            )
            // Supabase-js doesn't throw on a query error, so this used to
            // go straight to deleting the locks even when the insert above
            // silently failed — the CUSDEC's lock was gone for good with no
            // approval ever created, and no way to retry. Now the lock is
            // only released once the approval row is confirmed created;
            // on failure it's logged and the lock stays so the next
            // Mail/Download attempt on this document can retry it.
            if (apErr) {
              console.error('[log-document-action] boat_note doc_approvals insert failed, keeping locks for retry:', apErr.message, apErr)
            } else {
              await supabaseAdmin.from('boat_note_locks').delete().in('cusdec_id', cusdecIds)
            }
          }
        }
      } catch { /* non-fatal — doc_approvals is supplemental */ }
    }

    res.json({ ok: true })
  } catch (err: any) {
    console.error('[log-document-action] error:', err)
    res.status(500).json({ error: err.message })
  }
}