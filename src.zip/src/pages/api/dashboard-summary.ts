import type { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@supabase/supabase-js'
import { requireAuth } from '@/lib/serverAuth'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

// ── සිංහලෙන් ──────────────────────────────────────────────────────────────
// Dashboard එකේ pending card ඔක්කොම මෙතනින් හැදෙනවා:
//   Shipments Pending — CUSDEC එකක් තාම match වෙලා නැති shipment entry
//   CDN Pending       — CAP එක තාම පිරිලා නැති CUSDEC (cdn ගණන < cap)
//   Boat Note Pending — CAP පිරිලා, ඒත් හැම CDN එකක්ම boat note pass නෑ
//   Export Release    — boat note pass වෙලා, ඒත් release තාම නෑ
// Pick කරගෙන ඉන්න Boat Note batch එකක් lock වෙලා තියෙනවා නම් ඒක
// automation එකෙන් pass වුණත් ලැයිස්තුවෙන් අයින් වෙන්නේ නෑ.
// ──────────────────────────────────────────────────────────────────────────
// Powers the Dashboard's four pending-work cards, each meaning something
// specific in the real cusdec -> cdn -> boat note -> export release
// pipeline (none of this maps to the generic `status` columns the old
// dashboard queries used):
//
// - Shipments Pending: temporary_shipments rows still sitting unmatched — a
//   Shipment Entry was opened but no CUSDEC has been uploaded/matched to it
//   yet (a matching CUSDEC upload merges + deletes the row, per
//   save-to-table.ts's auto-match step).
// - CDN Pending: CUSDECs whose CAP isn't filled yet (CDN row count < CAP).
// - Boat Note Pending: CUSDECs whose CAP *is* complete but not every CDN has
//   passed Boat Note check yet (not blue).
// - Export Release Pending: CUSDECs that passed Boat Note (blue) but haven't
//   passed Export Release yet (not green).
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).end()
  try {
    const authed = await requireAuth(req)
    if (!authed.ok) return res.status(authed.status).json({ error: authed.error })

    const { data: callerProf } = await supabaseAdmin.from('profiles').select('is_admin').eq('id', authed.userId).maybeSingle()

    let shipmentsQuery = supabaseAdmin.from('temporary_shipments')
      .select('id, reference, shipper, invoice_number, packing_number, new_invoice, new_packing, cap, invoice_drive_url, packing_drive_url, license_drive_url, created_at, locked_by, locked_by_name')
      .order('created_at', { ascending: false })
    // Same visibility rule as temp-shipments.ts GET — a picked shipment
    // shouldn't keep showing up as "pending" for everyone else's dashboard.
    if (!callerProf?.is_admin) shipmentsQuery = shipmentsQuery.or(`locked_by.is.null,locked_by.eq.${authed.userId}`)

    const [{ data: shipments }, { data: cusdecs }, { data: cdns }, { data: reasonDocsRaw }, { data: vesselTriggers }] = await Promise.all([
      shipmentsQuery,
      supabaseAdmin.from('cusdec').select('id, code, number, exporter, cap, export_release_passed, boat_note_url, party_copy_url'),
      supabaseAdmin.from('cdn').select('id, code, cusdec_number, container_no, vessel, voyage, boat_note_passed, export_release_passed'),
      // Reason-tagged Quick Upload queue — a document tagged reason:'CUSDEC
      // Passed' counts as pending only while it's still sitting unpicked in
      // the Incoming pool (dashboard_notifications.is_active) — Pick turns
      // that off, Return turns it back on, same as Incoming itself. It was
      // previously counting every such row regardless of pick state, so a
      // document someone had already picked (and was sitting in their My
      // Picked Tasks) kept inflating this count until it got Mailed/Downloaded.
      supabaseAdmin.from('document_uploads').select('id, file_name, reason, reason_note, created_at').eq('reason', 'CUSDEC Passed').order('created_at', { ascending: false }),
      supabaseAdmin.from('vessel_triggers').select('vessel, voyage, opening_time, closing_time, etb'),
    ])
    // Boat Note Pending rows currently mid-pick (merged, not yet Mailed/
    // Downloaded) stay pinned in the list — and un-pickable — even if the
    // automation scraper flips cdn.boat_note_passed on all their CDNs in
    // the meantime, so a pick in progress can never get silently duplicated
    // or vanish out from under whoever's handling it. Released in
    // log-document-action.ts once Mail/Download resolves it.
    const { data: boatNoteLocks } = await supabaseAdmin.from('boat_note_locks').select('cusdec_id, locked_by_name')
    const lockedCusdecIds = new Set((boatNoteLocks || []).map(l => l.cusdec_id))
    const lockedByName = new Map((boatNoteLocks || []).map(l => [l.cusdec_id, l.locked_by_name]))
    let reasonDocs = reasonDocsRaw || []
    if (reasonDocs.length) {
      const { data: activeNotifs } = await supabaseAdmin.from('dashboard_notifications')
        .select('document_id').eq('is_active', true).in('document_id', reasonDocs.map(d => d.id))
      const activeIds = new Set((activeNotifs || []).map(n => n.document_id))
      reasonDocs = reasonDocs.filter(d => activeIds.has(d.id))
    }

    const cdnPending: any[] = []
    const boatNotePending: any[] = []
    const releasePending: any[] = []

    // Closing Time Passed / vessel-trigger lookup — matched by voyage exactly
    // (trimmed/uppercased) plus a *fuzzy* vessel-name match (same leading
    // characters), not a full exact vessel-name match. CDN uploads and the
    // scraped Vessel Trigger schedule don't always spell the vessel name
    // identically (extra suffix, punctuation, etc.), and requiring an exact
    // match meant this silently matched nothing. Voyage is still the primary
    // key (same voyage number can appear against more than one vessel in the
    // schedule) — vessel is only there to disambiguate between candidates
    // sharing that voyage.
    // Voyage codes are compared without spaces/punctuation ("012 E" vs
    // "012E"), otherwise a harmless formatting difference between the CDN
    // and the scraped schedule means the container never matches.
    const normVoyage = (v: string) => (v || '').toUpperCase().replace(/[^A-Z0-9]/g, '')
    const normVessel = (v: string) => (v || '').toUpperCase().replace(/[^A-Z0-9]/g, '')
    const vesselFuzzyMatch = (a: string, b: string): boolean => {
      const na = normVessel(a), nb = normVessel(b)
      if (!na || !nb) return false
      const len = Math.min(5, na.length, nb.length)
      return na.slice(0, len) === nb.slice(0, len)
    }
    const triggersByVoyage = new Map<string, typeof vesselTriggers>()
    for (const t of vesselTriggers || []) {
      const key = normVoyage(t.voyage)
      if (!triggersByVoyage.has(key)) triggersByVoyage.set(key, [])
      triggersByVoyage.get(key)!.push(t)
    }
    const findTrigger = (vessel: string, voyage: string) => {
      if (!vessel || !voyage) return null
      const candidates = triggersByVoyage.get(normVoyage(voyage)) || []
      return candidates.find(t => vesselFuzzyMatch(vessel, t.vessel)) || null
    }

    // The Vessel Trigger schedule is scraped as plain text, so closing_time
    // can arrive as "2026-09-30 14:00", "30/09/2026 14:00", "30-09-2026
    // 2:00 PM", "30 Sep 2026 14:00" etc. The old check was
    // new Date(text.replace(' ', 'T')), which only understands the first
    // shape — for anything else it produced an invalid date and the
    // container was silently skipped, so nothing ever showed as "closing
    // time passed". This reads all the common shapes and treats the value as
    // Sri Lanka time (+05:30) no matter where the server runs.
    const MONTHS: Record<string, number> = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 }
    const parseSLDateTime = (raw: string): number | null => {
      const s = String(raw || '').trim()
      if (!s) return null
      let y: number, mo: number, d: number
      let rest = ''
      let m = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(.*)$/)
      if (m) { y = +m[1]; mo = +m[2] - 1; d = +m[3]; rest = m[4] }
      else if ((m = s.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})(.*)$/))) { d = +m[1]; mo = +m[2] - 1; y = +m[3]; if (y < 100) y += 2000; rest = m[4] }
      else if ((m = s.match(/^(\d{1,2})[\s-]+([A-Za-z]{3})[A-Za-z]*[\s,-]+(\d{2,4})(.*)$/))) {
        const mi = MONTHS[m[2].toLowerCase()]; if (mi === undefined) return null
        d = +m[1]; mo = mi; y = +m[3]; if (y < 100) y += 2000; rest = m[4]
      } else return null
      let hh = 0, mm = 0, ss = 0
      const t = rest.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?/i)
      if (t) {
        hh = +t[1]; mm = +t[2]; ss = t[3] ? +t[3] : 0
        const ap = (t[4] || '').toUpperCase()
        if (ap === 'PM' && hh < 12) hh += 12
        if (ap === 'AM' && hh === 12) hh = 0
      }
      if (mo < 0 || mo > 11 || d < 1 || d > 31 || hh > 23 || mm > 59) return null
      // Date.UTC of the wall-clock value, minus the +05:30 offset = the real instant.
      return Date.UTC(y, mo, d, hh, mm, ss) - (5 * 60 + 30) * 60_000
    }

    const nowMs = Date.now()
    const closingPassed: any[] = []
    for (const d of cdns || []) {
      if (d.boat_note_passed || d.export_release_passed) continue
      const match = findTrigger(d.vessel, d.voyage)
      if (!match?.closing_time) continue
      const closingMs = parseSLDateTime(match.closing_time)
      if (closingMs === null || nowMs <= closingMs) continue
      closingPassed.push({ cdnId: d.id, containerNo: d.container_no, cusdecNumber: d.cusdec_number, vessel: d.vessel, voyage: d.voyage, closingTime: match.closing_time })
    }

    for (const c of cusdecs || []) {
      const own = (cdns || []).filter(d => d.code === c.code && d.cusdec_number === c.number)
      const cap = parseInt(c.cap || '', 10)
      const capKnown = !!cap && !Number.isNaN(cap)
      const capComplete = !capKnown || own.length >= cap
      // Missing the capComplete check here let a CUSDEC still waiting on
      // more CDN uploads show up in Export Release Pending the moment its
      // few uploaded-so-far CDN rows all happened to individually pass Boat
      // Note — Automation's Export Release Check panel already required
      // capComplete (see isBoatNotePassed in automationChecks.ts), so the
      // two disagreed: Dashboard showed a pending count with nothing to
      // actually show in the Automation tab's eligible list.
      const allBoatNotePassed = capComplete && own.length > 0 && own.every(d => d.boat_note_passed)

      const containers = own
        .filter(d => d.vessel && d.voyage)
        .map(d => {
          const trigger = findTrigger(d.vessel, d.voyage)
          return {
            containerNo: d.container_no, vessel: d.vessel, voyage: d.voyage,
            trigger: trigger ? { openingTime: trigger.opening_time, closingTime: trigger.closing_time, etb: trigger.etb } : null,
          }
        })

      const locked = lockedCusdecIds.has(c.id)
      if (capKnown && own.length < cap && !locked) {
        cdnPending.push({ cusdecId: c.id, number: c.number, exporter: c.exporter, cap, cdnCount: own.length, containers })
      } else if ((capComplete && !allBoatNotePassed) || locked) {
        boatNotePending.push({
          cusdecId: c.id, number: c.number, exporter: c.exporter, cap: cap || null, cdnCount: own.length,
          passedCount: own.filter(d => d.boat_note_passed).length, containers,
          hasBoatNote: !!c.boat_note_url, hasPartyCopy: !!c.party_copy_url,
          locked, lockedByName: lockedByName.get(c.id) || null,
        })
      }

      if (allBoatNotePassed && !c.export_release_passed && !locked) {
        releasePending.push({ cusdecId: c.id, number: c.number, exporter: c.exporter })
      }
    }

    res.json({
      shipmentsPending: { count: (shipments || []).length, items: shipments || [] },
      cdnPending: { count: cdnPending.reduce((s, c) => s + (c.cap - c.cdnCount), 0), items: cdnPending },
      boatNotePending: { count: boatNotePending.length, items: boatNotePending },
      releasePending: { count: releasePending.length, items: releasePending },
      pendingCusdecPassed: { count: (reasonDocs || []).length, items: reasonDocs || [] },
      closingPassed: { count: closingPassed.length, items: closingPassed },
    })
  } catch (err: any) {
    console.error('[dashboard-summary] error:', err)
    res.status(500).json({ error: err.message })
  }
}