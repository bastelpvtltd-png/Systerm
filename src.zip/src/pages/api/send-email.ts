import type { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@supabase/supabase-js'
import { requireAuth } from '@/lib/serverAuth'
import { getDriveClient } from '@/lib/driveFolders'
const nodemailer = require('nodemailer')

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

// PDFs sent as base64 (Mail-only sends that were never saved) can be bigger
// than Next's 1 MB default body limit. (Vercel itself caps a request at ~4.5 MB.)
export const config = { api: { bodyParser: { sizeLimit: '10mb' } } }

// A Drive "view" link (drive.google.com/file/d/<id>/view) is a WEB PAGE, not
// the file — fetching it and attaching the result produces a "PDF" that is
// really HTML, which is why a recipient's PDF wouldn't open even though the
// mail itself went through. So a saved file is always taken from Drive
// itself: by file id, through the Drive API (the same login the uploads use).
function driveFileId(url: string): string | null {
  try {
    const u = new URL(url)
    if (!/(^|\.)(drive|docs)\.google\.com$/.test(u.hostname)) return null
    return u.pathname.match(/\/d\/([\w-]+)/)?.[1] || u.searchParams.get('id')
  } catch { return null }
}

async function downloadFromDrive(fileId: string): Promise<Buffer> {
  const drive: any = getDriveClient()
  const r = await drive.files.get({ fileId, alt: 'media', supportsAllDrives: true }, { responseType: 'arraybuffer' })
  return Buffer.from(r.data as ArrayBuffer)
}

// Never send a broken attachment silently: a ".pdf" whose bytes aren't a PDF
// fails the send with a clear message instead of arriving as a file nobody
// can open.
async function loadAttachment(a: Attachment): Promise<{ filename: string; content: Buffer; contentType?: string }> {
  let buf: Buffer | null = null
  if (a.base64) {
    // Mail-only send of a file that was never saved — bytes came from the page.
    buf = Buffer.from(a.base64, 'base64')
  } else {
    const id = driveFileId(a.url!)
    if (id) {
      try { buf = await downloadFromDrive(id) }
      catch (e: any) { console.error('[send-email] Drive API download failed, trying public link:', e?.response?.data || e?.message) }
      if (!buf) {
        const r = await fetch(`https://drive.google.com/uc?export=download&id=${id}`, { redirect: 'follow' })
        if (r.ok) buf = Buffer.from(await r.arrayBuffer())
      }
    } else {
      const r = await fetch(a.url!, { redirect: 'follow' })
      if (!r.ok) throw new Error(`Could not download "${a.filename}" to attach it (HTTP ${r.status})`)
      buf = Buffer.from(await r.arrayBuffer())
    }
    if (!buf) throw new Error(`Could not download "${a.filename}" from Drive to attach it. Nothing was sent.`)
  }
  const isPdfBytes = buf.subarray(0, 1024).includes('%PDF-')
  const looksLikePdfName = /\.pdf$/i.test(a.filename)
  if (looksLikePdfName && !isPdfBytes) {
    throw new Error(`"${a.filename}" could not be attached — Drive returned a web page instead of the PDF. Nothing was sent.`)
  }
  // A renamed file with no ".pdf" on the end arrives as an unknown file type
  // that can't be opened — give real PDFs the extension and type.
  if (isPdfBytes) {
    return { filename: looksLikePdfName ? a.filename : `${a.filename}.pdf`, content: buf, contentType: 'application/pdf' }
  }
  return { filename: a.filename, content: buf }
}

// Most attachments are Drive-hosted files fetched by url; a few callers
// (e.g. Done Boat Note's merge, which is deliberately never saved anywhere)
// only have the bytes in memory, so they send base64 directly instead.
interface Attachment { filename: string; url?: string; base64?: string }

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()
  try {
    const { to, cc, bcc, subject, body, boatNotes, cusdecNo, attachments, useDocsAccount } = req.body as {
      to: string; cc?: string; bcc?: string; subject: string; body?: string; boatNotes?: any[]; cusdecNo?: string
      attachments?: Attachment[]; useDocsAccount?: boolean
    }
    if (!to || !subject) return res.status(400).json({ error: 'Missing to or subject' })

    // Document emails (Upload Docs / Shipment Overview) send from a separate
    // docs.bastel@gmail.com mailbox instead of the boat-note account, so
    // recipients see mail specifically about their documents from that address.
    const user = useDocsAccount ? process.env.DOCS_GMAIL_USER : process.env.GMAIL_USER
    const pass = useDocsAccount ? process.env.DOCS_GMAIL_APP_PASS : process.env.GMAIL_APP_PASS
    if (!user || !pass) return res.status(500).json({ error: `${useDocsAccount ? 'DOCS_GMAIL_USER/DOCS_GMAIL_APP_PASS' : 'GMAIL_USER/GMAIL_APP_PASS'} not configured` })

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user, pass },
    })

    let mailAttachments: { filename: string; content: Buffer; contentType?: string }[] | undefined
    if (attachments?.length) {
      mailAttachments = await Promise.all(attachments.map(loadAttachment))
    }

    const html = `
      <h3>${subject}</h3>
      <p>${(body || '').replace(/\n/g, '<br>')}</p>
      ${boatNotes?.length ? `
        <hr>
        <h4>Boat Note Summary:</h4>
        <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;font-size:13px">
          <tr style="background:#1B3A5C;color:white">
            <th>#</th><th>Container</th><th>CDN No.</th><th>Driver</th><th>Gross (Kg)</th>
          </tr>
          ${boatNotes.map((bn: any, i: number) => `
            <tr>
              <td>${i+1}</td>
              <td>${bn.container_no}</td>
              <td>${bn.cdn_no}</td>
              <td>${bn.driver_name}</td>
              <td>${bn.gross_mass}</td>
            </tr>`).join('')}
        </table>
      ` : ''}
      <hr>
      <p style="color:#999;font-size:12px">Sent from Export Management System · CUSDEC ${cusdecNo || ''}</p>
    `

    await transporter.sendMail({
      from: `"Bastel Official System" <${user}>`,
      to, cc: cc || undefined, bcc: bcc || undefined, subject, html,
      attachments: mailAttachments,
    })

    // Mail History (Preview tab) reads this — best-effort, a logging failure
    // shouldn't fail a mail that already sent successfully.
    try {
      const authed = await requireAuth(req)
      let sentByName = ''
      if (authed.ok) {
        const { data: prof } = await supabaseAdmin.from('profiles').select('username, full_name').eq('id', authed.userId).maybeSingle()
        sentByName = prof?.full_name || prof?.username || ''
      }
      await supabaseAdmin.from('email_log').insert({
        sent_by: authed.ok ? authed.userId : null, sent_by_name: sentByName,
        to_addresses: to, cc_addresses: cc || null, bcc_addresses: bcc || null,
        subject, attachment_names: (attachments || []).map(a => a.filename).join(', ') || null,
      })
    } catch (e: any) {
      console.error('[send-email] history log failed:', e.message)
    }

    res.json({ ok: true })
  } catch (err: any) {
    console.error('send-email error:', err.message)
    res.status(500).json({ error: err.message })
  }
}