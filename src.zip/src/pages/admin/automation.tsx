import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/router'
import AdminLayout, { usePermission } from '@/components/admin/AdminLayout'
import { authHeader } from '@/lib/supabase'
import { yearOf } from '@/lib/flexibleDate'
import EmailPdfModal from '@/components/admin/EmailPdfModal'
import { BarcodeEnterPanel, TricoGatePassPanel, TricoCheckPanel } from '@/components/admin/AutomationPortalPanels'
import {
  Zap, Barcode as BarcodeIcon, Truck, RefreshCw,
  ClipboardCheck, ShieldCheck, Loader, Search, Copy, Plus, Trash2,
  StickyNote, Save, Mail, CheckSquare, Square, AlertTriangle, Clock, Ship,
  GitMerge, ExternalLink, FilePen, Upload, Download, Type, Highlighter,
  ChevronLeft, ChevronRight, X, Eraser,
} from 'lucide-react'

type AutomationTab =
  | 'barcode' | 'trico-check' | 'trico' | 'trico-yard' | 'data-updates'
  | 'boat-note-create' | 'party-copy-create' | 'merge-pdf'
  | 'boat-note-check' | 'export-release' | 'vessel-trigger'
  | 'conflict-review' | 'cdn-approval' | 'notes' | 'pdf-editor' | 'monthly-reports'

interface CusdecRec { id: string; code: string; number: string; date: string; exporter: string; consignee: string; vessel: string; voyage_no: string; bl_no: string; gross_mass: string; net_mass: string; discharge_port: string; location_of_goods: string; cap: string; hs_code: string; preference: string; procedure_code: string; delivery_terms: string; amount: string; pkges: string; export_release_passed?: boolean; tin_vat?: string }

// The stored CUSDEC number often carries its serial letter/space (e.g.
// "E 38812") — the Customs lookup form wants just the digits.
function cleanCusdecNumber(raw: string): string { return (raw || '').replace(/\D/g, '') }
interface CdnRec { id: string; code: string; cusdec_number: string; shipper: string; consignee: string; container_no: string; goods_description: string; gross_mass: string; vessel: string; voyage: string; voyage_date: string; bl_no: string; slpa_no: string; voc: string; coc: string; lorry_no: string; trailer_no: string; loading_port: string; discharge_port: string; driver_name: string; pkg_no: string; pkg_type: string; volume: string; seal_no: string; con_type: string; marks: string; cdn_no: string; boat_note_passed?: boolean; export_release_passed?: boolean }

const SUB_TABS: { key: AutomationTab; label: string; icon: any; permission: string }[] = [
  { key: 'barcode', label: 'Barcode Enter', icon: BarcodeIcon, permission: 'section:automation.barcode-enter' },
  { key: 'trico-check', label: 'Trico Checking', icon: Truck, permission: 'section:automation.trico-checking' },
  { key: 'trico', label: 'Trico Gate Passes', icon: Truck, permission: 'section:automation.trico-gate-pass' },
  { key: 'data-updates', label: 'Data Updates', icon: RefreshCw, permission: 'section:automation.data-updates' },
  { key: 'boat-note-create', label: 'Boat Note Create', icon: Ship, permission: 'section:automation.boat-note-create' },
  { key: 'party-copy-create', label: "Party's Copy Create", icon: Copy, permission: 'section:automation.party-copy-create' },
  { key: 'merge-pdf', label: 'Merge PDF', icon: GitMerge, permission: 'section:automation.merge-pdf' },
  { key: 'boat-note-check', label: 'Boat Note Check', icon: ClipboardCheck, permission: 'section:automation.boat-note-check' },
  { key: 'export-release', label: 'Export Release Check', icon: ShieldCheck, permission: 'section:automation.export-release-check' },
  { key: 'vessel-trigger', label: 'Vessel Triggers', icon: Ship, permission: 'section:automation.vessel-trigger' },
  { key: 'conflict-review', label: 'Conflict Review', icon: GitMerge, permission: 'section:automation.conflict-review' },
  { key: 'cdn-approval', label: 'CDN Approval', icon: CheckSquare, permission: 'section:automation.cdn-approval' },
  { key: 'notes', label: 'System Logic & Integration Notes', icon: StickyNote, permission: 'section:automation.notes' },
  { key: 'pdf-editor', label: 'PDF Editor', icon: FilePen, permission: 'section:automation.pdf-editor' },
  { key: 'monthly-reports', label: 'Monthly Reports', icon: Clock, permission: 'section:automation.monthly-reports' },
  { key: 'trico-yard', label: 'Trico Yard View', icon: Truck, permission: 'section:automation.trico-yard' },
]

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>
      {children}
    </div>
  )
}

function AutomationContent() {
  const { has } = usePermission()
  const visibleTabs = SUB_TABS.filter(t => has(t.permission))
  const router = useRouter()
  const [tab, setTab] = useState<AutomationTab>(visibleTabs[0]?.key || 'barcode')
  // Lets the Dashboard's pending-work cards deep-link straight into the
  // relevant sub-tab, e.g. /admin/automation?tab=export-release.
  useEffect(() => {
    const q = router.query.tab
    if (typeof q === 'string' && visibleTabs.some(t => t.key === q)) setTab(q as AutomationTab)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router.query.tab])

  return (
    <div className="p-6">
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2"><Zap size={20} className="text-amber-500"/>Automation</h1>
        <p className="text-gray-500 text-sm mt-0.5">Cusdec XML, CDN text output, port/gov portal shortcuts, and Boat Note tools in one place</p>
      </div>

      <div className="flex gap-1 mb-6 bg-gray-100 p-1 rounded-xl w-fit flex-wrap">
        {visibleTabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
              tab === t.key ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
            }`}>
            <t.icon size={13}/>{t.label}
          </button>
        ))}
      </div>

      {tab === 'barcode' && <BarcodeEnterPanel/>}
      {tab === 'trico-check' && <TricoCheckPanel scheduler={<SchedulerControl panel="trico_check" label="Auto-check"/>}/>}
      {tab === 'trico' && <TricoGatePassPanel/>}
      {tab === 'trico-yard' && <TricoYardPanel/>}
      {tab === 'data-updates' && <DataUpdates/>}
      {tab === 'boat-note-create' && <AutoCreatePanel panel="boat_note_create" apiPath="/api/auto-create-boat-notes" title="Boat Note Create" docLabel="Boat Note"/>}
      {tab === 'party-copy-create' && <AutoCreatePanel panel="party_copy_create" apiPath="/api/auto-create-parties-copies" title="Party's Copy Create" docLabel="Party's Copy"/>}
      {tab === 'merge-pdf' && <MergePdfPanel/>}
      {tab === 'boat-note-check' && <BoatNoteCheckPanel/>}
      {tab === 'export-release' && <ExportReleaseCheckPanel/>}
      {tab === 'vessel-trigger' && <VesselTriggerPanel/>}
      {tab === 'conflict-review' && <ConflictReviewPanel/>}
      {tab === 'cdn-approval' && <CdnApprovalPanel/>}
      {tab === 'notes' && <SystemNotes/>}
      {tab === 'pdf-editor' && <PdfEditorPanel/>}
      {tab === 'monthly-reports' && <MonthlyReportsPanel/>}
    </div>
  )
}

// Off by default — the cron itself (cron-monthly-reports.ts, runs daily,
// only acts on the 10th) checks this same flag before generating anything,
// so flipping it here is the one switch that actually controls whether
// auto-reports happen at all.
function MonthlyReportsPanel() {
  const [enabled, setEnabled] = useState(false)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    authHeader().then(h => fetch('/api/app-settings?key=monthly_reports_enabled', { headers: h }))
      .then(r => r.json()).then(d => setEnabled(d.value === 'true'))
      .finally(() => setLoading(false))
  }, [])

  async function toggle() {
    setSaving(true)
    try {
      const next = !enabled
      const res = await fetch('/api/app-settings', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ key: 'monthly_reports_enabled', value: String(next) }),
      })
      if (res.ok) {
        setEnabled(next)
        // Switching a panel ON can start its work right away (Boat Note /
        // Party's Copy Create pass their Run Now here) instead of sitting
        // idle until the next scheduled interval comes round.
        if (next && onTurnedOn) onTurnedOn()
      }
    } finally { setSaving(false) }
  }

  return (
    <div className="card max-w-lg">
      <h2 className="font-semibold text-gray-900 text-sm mb-2">Monthly Reports</h2>
      <p className="text-xs text-gray-500 mb-4">
        When ON, a balance report (PDF) is generated automatically for every user on the 10th of each
        month — same as clicking "Generate Report" in My Tasks' Balance panel for each of them.
        Off by default so nothing runs unattended until this is explicitly turned on.
      </p>
      {loading ? (
        <Loader size={16} className="animate-spin text-gray-400"/>
      ) : (
        <button onClick={toggle} disabled={saving}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white disabled:opacity-50 ${enabled ? '' : ''}`}
          style={{ background: enabled ? '#22A87A' : '#9ca3af' }}>
          {saving ? <Loader size={13} className="animate-spin"/> : null}
          {enabled ? 'ON — click to turn off' : 'OFF — click to turn on'}
        </button>
      )}
    </div>
  )
}

// Barcode Enter, Trico Checking and Trico Gate Passes live in
// components/admin/AutomationPortalPanels.tsx (they run through the browser
// worker queue — see worker/README.md).

// ── Data Updates ───────────────────────────────────────────────────────────
function DataUpdates() {
  return (
    <div className="card max-w-xl">
      <h2 className="font-semibold text-gray-900 text-sm mb-2">Data Updates</h2>
      <p className="text-xs text-gray-500 mb-4">To manually correct any CUSDEC/CDN/Barcode/Boat Note row (fix a typo, update a status, etc.), use the Database admin page — same tables this Automation tab reads from.</p>
      <a href="/admin/database" className="btn-primary inline-flex items-center gap-2"><RefreshCw size={14}/>Open Database</a>
    </div>
  )
}

// ── Status Checks (Boat Note Check / Export Release Check) ──────────
// Both hit the real public (no-login) lookup on each site directly — see
// src/pages/api/boat-note-check.ts and export-release-check.ts for how the
// request/response shape was confirmed against the live pages. Each offers
// a Manual Trigger (check one picked item) and an Auto Trigger (loop every
// item that still needs checking) — a passed Boat Note check turns that CDN
// blue; a passed Export Release turns the CUSDEC (and its already-blue CDNs)
// green. Export Release only ever runs against CDNs/CUSDECs that already
// passed Boat Note.
// Shared by both check panels — plain-minutes interval editor + "last ran"
// readout for the scheduled cron (cron-check-pending.ts), which is what
// actually applies this interval; this control only reads/writes the number.
function SchedulerControl({ panel, label, onTurnedOn }: { panel: 'boat_note' | 'export_release' | 'vessel_trigger' | 'boat_note_create' | 'party_copy_create' | 'trico_check'; label: string; onTurnedOn?: () => void }) {
  const [minutes, setMinutes] = useState<string>('')
  const [lastRunAt, setLastRunAt] = useState<string | null>(null)
  const [enabled, setEnabled] = useState(true)
  const [saving, setSaving] = useState(false)
  const [savedMsg, setSavedMsg] = useState('')
  const [toggling, setToggling] = useState(false)

  async function load(silent = false) {
    const res = await fetch('/api/automation-runs', { headers: await authHeader() })
    const d = await res.json()
    const row = (d.runs || []).find((r: any) => r.panel === panel)
    if (!row) return
    // Only the initial (non-silent) load syncs the minutes input — a
    // background poll shouldn't overwrite digits the user is mid-typing.
    if (!silent) setMinutes(String(row.interval_minutes))
    setLastRunAt(row.last_run_at)
    setEnabled(row.enabled !== false)
  }
  useEffect(() => {
    load()
    // "Last ran" is now genuinely live (the hourly GitHub Actions ping keeps
    // bumping it) — poll so it updates here without a page refresh.
    const t = setInterval(() => load(true), 15000)
    return () => clearInterval(t)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  async function save() {
    setSaving(true); setSavedMsg('')
    try {
      const res = await fetch('/api/automation-runs', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ panel, interval_minutes: Number(minutes) }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setSavedMsg('✓ Saved')
    } catch (e: any) {
      setSavedMsg(`✗ ${e.message}`)
    } finally {
      setSaving(false)
    }
  }

  // Persistent on/off switch — the cron itself already runs independent of
  // any browser session, so "persists across refresh" is automatic here;
  // this is just whether cron-check-pending.ts is allowed to act on this
  // panel or should skip it entirely until switched back on.
  async function toggleEnabled() {
    const next = !enabled
    setToggling(true)
    try {
      const res = await fetch('/api/automation-runs', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ panel, enabled: next }),
      })
      if (res.ok) {
        setEnabled(next)
        // Switching a panel ON can start its work right away (Boat Note /
        // Party's Copy Create pass their Run Now here) instead of sitting
        // idle until the next scheduled interval comes round.
        if (next && onTurnedOn) onTurnedOn()
      }
    } finally {
      setToggling(false)
    }
  }

  return (
    <div>
      <div className="flex items-center gap-2 text-xs flex-wrap">
        <button onClick={toggleEnabled} disabled={toggling}
          className={`flex items-center gap-1.5 px-2 py-1 rounded-full font-medium disabled:opacity-50 ${
            enabled ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-gray-100 text-gray-500 border border-gray-200'
          }`}>
          <span className={`w-1.5 h-1.5 rounded-full ${enabled ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}/>
          {enabled ? 'Live · Active' : 'Paused'}
        </button>
        <Clock size={13} className="text-gray-400"/>
        <span className="text-gray-500">{label} every</span>
        <input type="number" min={1} value={minutes} onChange={e => setMinutes(e.target.value)}
          className="input text-xs w-16 py-1"/>
        <span className="text-gray-500">min</span>
        <button onClick={save} disabled={saving} className="text-blue-600 hover:underline disabled:opacity-50">Save</button>
        {savedMsg && <span className={savedMsg.startsWith('✓') ? 'text-green-600' : 'text-red-600'}>{savedMsg}</span>}
        {lastRunAt && <span className="text-gray-400">· last ran {new Date(lastRunAt).toLocaleString('en-GB')}</span>}
      </div>
      <p className="text-[11px] text-gray-400 mt-1">This project's Vercel plan (Hobby) only fires the scheduler once/day — a shorter interval here just means it won't skip a day early once you upgrade to Pro; it can't run more than once a day until then.</p>
    </div>
  )
}

// Orphaned Data Monitor — surfaces records that can never be auto-checked
// (missing the one field the lookup needs) without cluttering the main
// pending queue above; collapsed by default since this is an audit view,
// not something that needs attention every time the panel opens.
function OrphanedDataMonitor({ label, count, items }: { label: string; count: number; items: { id: string; title: string; subtitle?: string }[] }) {
  const [open, setOpen] = useState(false)
  if (count === 0) return null
  return (
    <div className="mt-3 border-t border-gray-100 pt-2">
      <button onClick={() => setOpen(o => !o)} className="flex items-center gap-1.5 text-xs text-amber-600 hover:underline">
        <AlertTriangle size={12}/> {label} ({count}) {open ? '▲' : '▼'}
      </button>
      {open && (
        <div className="mt-2 space-y-1 max-h-40 overflow-y-auto">
          {items.map(it => (
            <div key={it.id} className="text-[11px] border border-amber-100 bg-amber-50 rounded p-1.5">
              <p className="font-medium text-amber-800">{it.title}</p>
              {it.subtitle && <p className="text-amber-600 truncate">{it.subtitle}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function useTriggerTimestamp(field: 'boatNote' | 'exportRelease') {
  const [info, setInfo] = useState<{ time: string; container?: string; cusdec?: string } | null>(null)
  useEffect(() => {
    authHeader().then(h =>
      fetch('/api/trigger-timestamps', { headers: h })
        .then(r => r.ok ? r.json() : null)
        .then(d => { if (d) setInfo(d[field] || null) })
        .catch(() => {})
    )
  }, [field])
  function fmt(iso: string | null | undefined) {
    if (!iso) return null
    try { return new Date(iso).toLocaleString('en-GB', { timeZone: 'Asia/Colombo', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) } catch { return iso }
  }
  const timeStr = info ? fmt(info.time) : null
  const ref = info ? (info.container || info.cusdec || null) : null
  return { timeStr, ref }
}

function useNextVessel() {
  const [vessel, setVessel] = useState<{ etb: string; vessel: string; voyage: string; opening: string; closing: string } | null>(null)
  useEffect(() => {
    authHeader().then(h =>
      fetch('/api/trigger-timestamps', { headers: h })
        .then(r => r.ok ? r.json() : null)
        .then(d => { if (d?.vessel) setVessel(d.vessel) })
        .catch(() => {})
    )
  }, [])
  function fmtDate(iso: string | null | undefined) {
    if (!iso) return '—'
    try { return new Date(iso).toLocaleString('en-GB', { timeZone: 'Asia/Colombo', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) } catch { return iso || '—' }
  }
  return vessel ? { ...vessel, etbStr: fmtDate(vessel.etb) } : null
}

// ── Boat Note Create / Party's Copy Create ──────────────────────────────
// Auto-generates + saves the PDF for every Boat-Note-pending CUSDEC (CAP
// complete, not yet Blue/Green) that doesn't have one saved yet — same
// generation path the manual Docs Create tab uses. Shippers Sheet Routing
// can't resolve a Fill/Print sheet for are skipped, not errored, since
// guessing the wrong tab is worse than not creating anything. See
// src/lib/autoCreateDocs.ts. Starts disabled (SchedulerControl) — a manual
// "Run Now" always works regardless of the scheduler toggle.
function AutoCreatePanel({ panel, apiPath, title, docLabel }: { panel: 'boat_note_create' | 'party_copy_create'; apiPath: string; title: string; docLabel: string }) {
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState<{ created: number; skipped: { cusdecNumber: string; reason: string }[]; errors: { cusdecNumber: string; error: string }[] } | null>(null)
  const [error, setError] = useState('')

  async function run() {
    if (busy) return
    setBusy(true); setError(''); setResult(null)
    try {
      const res = await fetch(apiPath, { method: 'POST', headers: await authHeader() })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Run failed')
      setResult({ created: d.created, skipped: d.skipped || [], errors: d.errors || [] })
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="card max-w-2xl">
      <h2 className="font-semibold text-gray-900 text-sm mb-2">{title}</h2>
      <p className="text-xs text-gray-500 mb-4">
        Finds every CUSDEC that's Boat Note pending (CAP complete — CDN count equals CAP — not yet Blue/Green) without a {docLabel} saved yet, generates it the same way the Docs Create tab does, and saves it (database + Drive). Ones already created are never created again.
        {panel === 'boat_note_create'
          ? ' Each new Boat Note also goes to the Activity Log (reason: Boat Note Passed) so it can be picked, mailed, downloaded or printed.'
          : " Party's Copy is only saved to the database and Drive — it does not go to the Activity Log."}
        {' '}Switching this panel to Live · Active runs it immediately for everything that's ready — it does not wait for the next scheduled time.
        Shippers without a Fill/Print Sheet Route configured in Templates are skipped, never guessed at.
      </p>
      <div className="mb-4">
        <SchedulerControl panel={panel} label={title} onTurnedOn={run}/>
      </div>
      <button onClick={run} disabled={busy} className="btn-primary flex items-center gap-2">
        {busy ? <Loader size={14} className="animate-spin"/> : <Zap size={14}/>}Run Now
      </button>
      {error && <p className="text-xs text-red-600 mt-3 flex items-center gap-1"><AlertTriangle size={13}/>{error}</p>}
      {result && (
        <div className="mt-4 space-y-3">
          <p className="text-xs font-medium text-green-700 bg-green-50 border border-green-200 rounded-lg px-3 py-2 inline-block">
            ✓ Created {result.created}
          </p>
          {result.skipped.length > 0 && (
            <div>
              <p className="text-xs font-medium text-amber-700 mb-1.5">Skipped ({result.skipped.length}) — no Sheet Route or source PDF:</p>
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {result.skipped.map((s, i) => (
                  <div key={i} className="text-[11px] border border-amber-100 bg-amber-50 rounded p-1.5">
                    <span className="font-medium text-amber-800">E {s.cusdecNumber}</span> — <span className="text-amber-600">{s.reason}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          {result.errors.length > 0 && (
            <div>
              <p className="text-xs font-medium text-red-700 mb-1.5">Errors ({result.errors.length}):</p>
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {result.errors.map((s, i) => (
                  <div key={i} className="text-[11px] border border-red-100 bg-red-50 rounded p-1.5">
                    <span className="font-medium text-red-800">E {s.cusdecNumber}</span> — <span className="text-red-600">{s.error}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ── Merge PDF ─────────────────────────────────────────────────────────────
// Pick one or more CUSDECs (Add button) — every Drive-hosted PDF already
// saved under each one (its own CUSDEC PDF, Boat Note, Party's Copy, its
// CDNs' PDFs, and those CDNs' Barcode PDFs — see /api/cusdec-documents.ts)
// shows up to tick individually, plus a separate section for uploading any
// number of local files that aren't in the system at all. Merge is always
// temporary: Download works straight off the in-memory result, and Mail
// uploads to Drive only long enough to attach it, deleting that file the
// moment the mail modal closes.
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve((reader.result as string).split(',')[1])
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}
interface CusdecDoc { key: string; label: string; url: string }
interface CusdecDocGroup { cusdecId: string; number: string; exporter: string; documents: CusdecDoc[] }

function MergePdfPanel() {
  const [cusdecs, setCusdecs] = useState<{ id: string; number: string; exporter: string }[]>([])
  const [search, setSearch] = useState('')
  const [selectedCusdecIds, setSelectedCusdecIds] = useState<string[]>([])
  const [groups, setGroups] = useState<CusdecDocGroup[]>([])
  const [loadingDocs, setLoadingDocs] = useState(false)
  const [checkedDocs, setCheckedDocs] = useState<Set<string>>(new Set())
  const [uploadFiles, setUploadFiles] = useState<File[]>([])
  const [outputName, setOutputName] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [merged, setMerged] = useState<{ base64: string; fileName: string } | null>(null)
  const [mailOpen, setMailOpen] = useState(false)
  const [mailUploading, setMailUploading] = useState(false)
  const [tempDriveUrl, setTempDriveUrl] = useState('')

  useEffect(() => {
    authHeader().then(h => fetch('/api/list-records?table=cusdec&limit=500', { headers: h })).then(r => r.json()).then(d => setCusdecs(d.records || [])).catch(() => {})
  }, [])

  useEffect(() => {
    if (!selectedCusdecIds.length) { setGroups([]); return }
    setLoadingDocs(true)
    authHeader().then(h => fetch(`/api/cusdec-documents?cusdec_ids=${selectedCusdecIds.join(',')}`, { headers: h }))
      .then(r => r.json()).then(d => setGroups(d.groups || [])).catch(() => {}).finally(() => setLoadingDocs(false))
  }, [selectedCusdecIds])

  const filteredCusdecs = cusdecs.filter(c =>
    !selectedCusdecIds.includes(c.id) && search.trim() &&
    (c.number?.toLowerCase().includes(search.toLowerCase()) || c.exporter?.toLowerCase().includes(search.toLowerCase()))
  ).slice(0, 8)

  function addCusdec(id: string) { setSelectedCusdecIds(prev => prev.includes(id) ? prev : [...prev, id]); setSearch('') }
  function removeCusdec(id: string) { setSelectedCusdecIds(prev => prev.filter(x => x !== id)) }
  function toggleDoc(key: string) {
    setCheckedDocs(prev => { const n = new Set(prev); n.has(key) ? n.delete(key) : n.add(key); return n })
  }

  async function merge() {
    setBusy(true); setError(''); setMerged(null)
    try {
      const driveSources = groups.flatMap(g => g.documents).filter(d => checkedDocs.has(d.key)).map(d => ({ driveUrl: d.url }))
      const uploadSources = await Promise.all(uploadFiles.map(async f => ({ base64: await fileToBase64(f), fileName: f.name })))
      const valid = [...driveSources, ...uploadSources]
      if (valid.length < 2) throw new Error('Tick or upload at least 2 PDFs to merge')
      const name = outputName.trim() || `Merged_${new Date().toISOString().slice(0, 10)}`
      const res = await fetch('/api/merge-pdfs', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ sources: valid, outputName: name }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Merge failed')
      setMerged({ base64: d.base64, fileName: d.fileName })
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  function downloadMerged() {
    if (!merged) return
    const bytes = Uint8Array.from(atob(merged.base64), c => c.charCodeAt(0))
    const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }))
    const a = document.createElement('a'); a.href = url; a.download = merged.fileName; a.click()
    URL.revokeObjectURL(url)
  }

  async function openMail() {
    if (!merged) return
    setMailUploading(true); setError('')
    try {
      const h = await authHeader()
      const dr = await fetch('/api/upload-to-drive', {
        method: 'POST', headers: { ...h, 'Content-Type': 'application/json' },
        body: JSON.stringify({ base64: merged.base64, fileName: merged.fileName, mimeType: 'application/pdf', docType: 'merged_pdf' }),
      })
      const dd = await dr.json()
      if (!dr.ok || !dd.driveLink) throw new Error(dd.error || 'Drive upload failed')
      setTempDriveUrl(dd.driveLink)
      setMailOpen(true)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setMailUploading(false)
    }
  }

  async function onMailClosed() {
    setMailOpen(false)
    if (tempDriveUrl) {
      const url = tempDriveUrl
      setTempDriveUrl('')
      fetch('/api/delete-temp-merge-file', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ drive_url: url }),
      }).catch(() => {})
    }
  }

  return (
    <div className="card max-w-2xl">
      <h2 className="font-semibold text-gray-900 text-sm mb-2">Merge PDF</h2>
      <p className="text-xs text-gray-500 mb-4">Pick CUSDECs to pull their already-saved documents from, and/or upload local PDFs, then merge under a name you choose.</p>

      <div className="mb-4">
        <label className="block text-xs font-medium text-gray-600 mb-1">Add a CUSDEC</label>
        <div className="relative">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400"/>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search number or exporter..."
            className="w-full pl-7 pr-3 py-1.5 border border-gray-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-400"/>
        </div>
        {filteredCusdecs.length > 0 && (
          <div className="mt-1 border border-gray-100 rounded-lg divide-y divide-gray-50 max-h-40 overflow-y-auto">
            {filteredCusdecs.map(c => (
              <button key={c.id} onClick={() => addCusdec(c.id)} className="w-full flex items-center justify-between px-2.5 py-1.5 text-xs hover:bg-gray-50 text-left">
                <span><span className="font-medium">E {c.number}</span> — <span className="text-gray-500">{c.exporter?.slice(0, 30)}</span></span>
                <Plus size={13} className="text-blue-600 flex-shrink-0"/>
              </button>
            ))}
          </div>
        )}
      </div>

      {selectedCusdecIds.length > 0 && (
        <div className="space-y-2 mb-4">
          {loadingDocs && <p className="text-xs text-gray-400">Loading documents…</p>}
          {groups.map(g => (
            <div key={g.cusdecId} className="border border-gray-100 rounded-lg p-2.5">
              <div className="flex items-center justify-between mb-1.5">
                <p className="text-xs font-semibold text-gray-800">E {g.number} — {g.exporter?.slice(0, 30)}</p>
                <button onClick={() => removeCusdec(g.cusdecId)} className="text-gray-300 hover:text-red-500"><X size={14}/></button>
              </div>
              {g.documents.length === 0 ? (
                <p className="text-[11px] text-gray-400">No saved documents found for this CUSDEC yet</p>
              ) : (
                <div className="space-y-1">
                  {g.documents.map(doc => (
                    <label key={doc.key} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-gray-50 rounded px-1 py-0.5">
                      <input type="checkbox" checked={checkedDocs.has(doc.key)} onChange={() => toggleDoc(doc.key)} className="w-3.5 h-3.5"/>
                      {doc.label}
                    </label>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="mb-4 pt-3 border-t border-gray-100">
        <label className="block text-xs font-medium text-gray-600 mb-1">Upload local PDFs</label>
        <input type="file" accept="application/pdf" multiple
          onChange={e => setUploadFiles(prev => [...prev, ...Array.from(e.target.files || [])])}
          className="text-xs"/>
        {uploadFiles.length > 0 && (
          <div className="mt-1.5 space-y-1">
            {uploadFiles.map((f, i) => (
              <div key={i} className="flex items-center justify-between text-xs border border-gray-100 rounded px-2 py-1">
                <span className="truncate">{f.name}</span>
                <button onClick={() => setUploadFiles(prev => prev.filter((_, ii) => ii !== i))} className="text-gray-300 hover:text-red-500 flex-shrink-0"><X size={13}/></button>
              </div>
            ))}
          </div>
        )}
      </div>

      <Field label="Output file name">
        <input value={outputName} onChange={e => setOutputName(e.target.value)} placeholder="e.g. Merged Documents" className="input text-sm"/>
      </Field>

      <button onClick={merge} disabled={busy} className="btn-primary flex items-center gap-2 mt-3">
        {busy ? <Loader size={14} className="animate-spin"/> : <GitMerge size={14}/>}Merge
      </button>
      {error && <p className="text-xs text-red-600 mt-3 flex items-center gap-1"><AlertTriangle size={13}/>{error}</p>}

      {merged && (
        <div className="mt-4 pt-4 border-t border-gray-100 flex gap-2">
          <button onClick={downloadMerged} className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm text-white font-medium" style={{ background: '#1B3A5C' }}>
            <Download size={14}/> Download
          </button>
          <button onClick={openMail} disabled={mailUploading} className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium border border-gray-200 text-gray-700 hover:bg-gray-50 disabled:opacity-50">
            {mailUploading ? <Loader size={14} className="animate-spin"/> : <Mail size={14}/>} Mail
          </button>
        </div>
      )}
      {mailOpen && merged && tempDriveUrl && (
        <EmailPdfModal
          attachments={[{ filename: merged.fileName, url: tempDriveUrl }]}
          onClose={onMailClosed}
        />
      )}
    </div>
  )
}

function BoatNoteCheckPanel() {
  const { timeStr: lastTime, ref: lastContainer } = useTriggerTimestamp('boatNote')
  const nextVessel = useNextVessel()
  const [cdns, setCdns] = useState<CdnRec[]>([])
  const [cusdecs, setCusdecs] = useState<CusdecRec[]>([])
  const [search, setSearch] = useState('')
  const [selectedId, setSelectedId] = useState('')
  const [busy, setBusy] = useState(false)
  const [autoBusy, setAutoBusy] = useState(false)
  const [autoProgress, setAutoProgress] = useState('')
  const [error, setError] = useState('')
  const [result, setResult] = useState<{ containerNo: string; vessel: string; level: string; status: string; passed: boolean } | null>(null)
  // Ad-hoc check — a container number typed by hand, not picked from the
  // list on the left. Useful to test-check something that isn't (or isn't
  // yet) a CDN row in the database — no cdnId is sent, so nothing here ever
  // gets written to the database.
  const [adhocContainer, setAdhocContainer] = useState('')
  const [adhocBusy, setAdhocBusy] = useState(false)
  const [adhocError, setAdhocError] = useState('')
  const [adhocResult, setAdhocResult] = useState<{ containerNo: string; vessel: string; level: string; status: string; passed: boolean } | null>(null)

  async function load() {
    const h = await authHeader()
    const [cr, dr] = await Promise.all([
      fetch('/api/list-records?table=cusdec&limit=500', { headers: h }).then(r => r.json()),
      fetch('/api/list-records?table=cdn&limit=500', { headers: h }).then(r => r.json()),
    ])
    setCusdecs(cr.records || [])
    setCdns(dr.records || [])
  }
  useEffect(() => {
    load()
    // Live — a container the hourly cron ping just passed (or an admin
    // action from elsewhere) shows blue here without a manual refresh. Only
    // the cusdec/cdn lists refresh; the search box, selection, and ad-hoc
    // form below are untouched by this.
    const t = setInterval(load, 15000)
    return () => clearInterval(t)
  }, [])

  // A CDN only counts as ready for auto-checking once its parent CUSDEC's
  // CAP is complete (every expected CDN has actually been uploaded) — same
  // rule ExportReleaseCheckPanel/isBoatNotePassed use. CAP not known at all
  // (blank/non-numeric) doesn't block it — there's nothing to wait for.
  // Manual Trigger (single-CDN, below) ignores this entirely by design.
  function isCapComplete(cdn: CdnRec): boolean {
    const cusdec = cusdecs.find(c => c.code === cdn.code && c.number === cdn.cusdec_number)
    const cap = parseInt(cusdec?.cap || '', 10)
    if (!cap || Number.isNaN(cap)) return true
    const own = cdns.filter(d => d.code === cdn.code && d.cusdec_number === cdn.cusdec_number)
    return own.length >= cap
  }

  const filtered = cdns.filter(c => !search || c.container_no?.toLowerCase().includes(search.toLowerCase()) || c.shipper?.toLowerCase().includes(search.toLowerCase()))
  const selected = cdns.find(c => c.id === selectedId) || null

  async function runOne(cdn: CdnRec) {
    const res = await fetch('/api/boat-note-check', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
      body: JSON.stringify({ containerNo: cdn.container_no, cdnId: cdn.id }),
    })
    const d = await res.json()
    if (!res.ok) throw new Error(d.error)
    return d
  }

  async function manualTrigger() {
    if (!selected) return
    setBusy(true); setError(''); setResult(null)
    try {
      const d = await runOne(selected)
      setResult(d)
      if (d.passed) await load()
    } catch (e: any) { setError(e.message) }
    finally { setBusy(false) }
  }

  async function runAdhoc() {
    if (!adhocContainer.trim()) return
    setAdhocBusy(true); setAdhocError(''); setAdhocResult(null)
    try {
      const res = await fetch('/api/boat-note-check', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ containerNo: adhocContainer.trim() }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setAdhocResult(d)
    } catch (e: any) { setAdhocError(e.message) }
    finally { setAdhocBusy(false) }
  }

  async function autoTrigger() {
    const pending = cdns.filter(c => !c.boat_note_passed && c.container_no && isCapComplete(c))
    if (!pending.length) { setAutoProgress('Nothing pending — every CAP-complete CDN already checked.'); return }
    setAutoBusy(true); setError('')
    let passedCount = 0
    for (let i = 0; i < pending.length; i++) {
      setAutoProgress(`Checking ${i + 1}/${pending.length} — ${pending[i].container_no}...`)
      try {
        const d = await runOne(pending[i])
        if (d.passed) passedCount++
      } catch { /* keep going through the rest of the batch */ }
      await new Promise(r => setTimeout(r, 400))
    }
    await load()
    setAutoProgress(`Done — ${passedCount}/${pending.length} newly passed.`)
    setAutoBusy(false)
  }

  function levelColorFor(level?: string) {
    return level === 'success' ? 'bg-green-50 border-green-200 text-green-700'
      : level === 'danger' ? 'bg-red-50 border-red-200 text-red-700'
      : 'bg-amber-50 border-amber-200 text-amber-700'
  }
  const levelColor = levelColorFor(result?.level)

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <div className="card">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <h2 className="font-semibold text-gray-900 text-sm">Select CDN</h2>
          <button onClick={autoTrigger} disabled={autoBusy} className="btn-secondary flex items-center gap-2 text-xs">
            {autoBusy ? <Loader size={13} className="animate-spin"/> : <Zap size={13}/>}Auto Trigger (all pending)
          </button>
        </div>
        <div className="mb-2"><SchedulerControl panel="boat_note" label="Auto-check"/></div>
        {nextVessel && (
          <div className="text-[11px] text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-md px-2 py-1.5 mb-3 flex items-center gap-1.5">
            <Ship size={10}/>
            <span>Next vessel: <strong>{nextVessel.vessel} {nextVessel.voyage}</strong> · ETB {nextVessel.etbStr} · Open {nextVessel.opening} → Close {nextVessel.closing}</span>
          </div>
        )}
        {autoProgress && <p className="text-xs text-gray-500 mb-2">{autoProgress}</p>}
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search container or shipper..." className="input mb-3"/>
        <div className="space-y-1 max-h-96 overflow-y-auto">
          {filtered.map(c => (
            <button key={c.id} onClick={() => setSelectedId(c.id)}
              className={`w-full text-left p-2.5 rounded-lg border-l-4 border text-xs ${
                selectedId === c.id ? 'bg-blue-50 border-blue-300' : 'border-gray-100 hover:bg-gray-50'
              } ${c.export_release_passed ? '!border-l-green-500' : c.boat_note_passed ? '!border-l-blue-500' : '!border-l-transparent'}`}>
              <p className="font-bold text-gray-800">
                {c.container_no || '—'}{' '}
                {c.export_release_passed
                  ? <span className="text-green-600 font-normal">· released</span>
                  : c.boat_note_passed
                    ? <span className="text-blue-600 font-normal">· passed</span>
                    : null}
              </p>
              <p className="text-gray-600 truncate">{c.shipper?.slice(0, 40)}</p>
            </button>
          ))}
          {filtered.length === 0 && <p className="text-xs text-gray-400 text-center py-6">No CDNs found</p>}
        </div>
        <OrphanedDataMonitor
          label="Empty Data (no Container No.)"
          count={cdns.filter(c => !c.container_no).length}
          items={cdns.filter(c => !c.container_no).map(c => ({ id: c.id, title: c.cdn_no || '(no CDN No.)', subtitle: c.shipper }))}
        />
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900 text-sm">Manual Trigger</h2>
          {lastTime && (
            <span className="text-[11px] text-green-700 bg-green-50 border border-green-200 rounded-md px-2 py-0.5 flex items-center gap-1">
              <Clock size={10}/>
              {lastContainer && <span className="font-mono font-bold">{lastContainer}</span>}
              {lastContainer && <span className="text-green-500">·</span>}
              {lastTime}
            </span>
          )}
        </div>
        {!selected ? (
          <p className="text-xs text-gray-400 text-center py-12">Select a CDN to check</p>
        ) : (
          <>
            <p className="text-xs text-gray-500 mb-3">Container: <span className="font-mono font-semibold text-gray-800">{selected.container_no}</span></p>
            <button onClick={manualTrigger} disabled={busy} className="btn-primary flex items-center gap-2">
              {busy ? <Loader size={14} className="animate-spin"/> : <Search size={14}/>}Check Status
            </button>
            {error && <p className="text-xs text-red-600 mt-3 flex items-center gap-1"><AlertTriangle size={13}/>{error}</p>}
            {result && (
              <div className={`mt-4 border rounded-lg p-3 text-sm ${levelColor}`}>
                <p><span className="font-semibold">Container:</span> {result.containerNo}</p>
                {result.vessel && <p><span className="font-semibold">Vessel / Voyage:</span> {result.vessel}</p>}
                <p className="mt-1">{result.status}</p>
              </div>
            )}
          </>
        )}

        <div className="mt-6 pt-5 border-t border-gray-100">
          <h3 className="font-semibold text-gray-900 text-sm mb-1">Check any container number</h3>
          <p className="text-xs text-gray-400 mb-3">Not tied to a CDN in the database — nothing here gets saved, just checked.</p>
          <div className="flex gap-2">
            <input value={adhocContainer} onChange={e => setAdhocContainer(e.target.value)} placeholder="Container number..." className="input flex-1"/>
            <button onClick={runAdhoc} disabled={adhocBusy || !adhocContainer.trim()} className="btn-secondary flex items-center gap-2 flex-shrink-0">
              {adhocBusy ? <Loader size={14} className="animate-spin"/> : <Search size={14}/>}Check
            </button>
          </div>
          {adhocError && <p className="text-xs text-red-600 mt-3 flex items-center gap-1"><AlertTriangle size={13}/>{adhocError}</p>}
          {adhocResult && (
            <div className={`mt-3 border rounded-lg p-3 text-sm ${levelColorFor(adhocResult.level)}`}>
              <p><span className="font-semibold">Container:</span> {adhocResult.containerNo}</p>
              {adhocResult.vessel && <p><span className="font-semibold">Vessel / Voyage:</span> {adhocResult.vessel}</p>}
              <p className="mt-1">{adhocResult.status}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function ExportReleaseCheckPanel() {
  const { timeStr: lastTime, ref: lastCusdec } = useTriggerTimestamp('exportRelease')
  const nextVessel = useNextVessel()
  const [cusdecs, setCusdecs] = useState<CusdecRec[]>([])
  const [cdns, setCdns] = useState<CdnRec[]>([])
  const [selectedId, setSelectedId] = useState('')
  const [form, setForm] = useState({ officeCode: '', serial: 'E', cusdecNumber: '', cusdecYear: '', consigneeTIN: '' })
  const [busy, setBusy] = useState(false)
  const [autoBusy, setAutoBusy] = useState(false)
  const [autoProgress, setAutoProgress] = useState('')
  const [error, setError] = useState('')
  const [result, setResult] = useState<{ found: boolean; message?: string; text?: string; passed?: boolean | null; releaseDate?: string | null } | null>(null)

  async function load() {
    const h = await authHeader()
    const [cr, dr] = await Promise.all([
      fetch('/api/list-records?table=cusdec&limit=500', { headers: h }).then(r => r.json()),
      fetch('/api/list-records?table=cdn&limit=500', { headers: h }).then(r => r.json()),
    ])
    setCusdecs(cr.records || [])
    setCdns(dr.records || [])
  }
  useEffect(() => {
    load()
    // Live — a CUSDEC the hourly cron ping just released shows green here
    // without a manual refresh.
    const t = setInterval(load, 15000)
    return () => clearInterval(t)
  }, [])

  // A CUSDEC only counts as "Boat Note passed" once every CDN row that
  // belongs to it (matched by code+number, same as the Overview page) is
  // itself boat_note_passed — matching the CAP is the give-away that there
  // aren't more containers still waiting to be checked.
  function boatNotePassed(c: CusdecRec): boolean {
    const own = cdns.filter(d => d.code === c.code && d.cusdec_number === c.number)
    if (!own.length) return false
    const cap = parseInt(c.cap || '', 10)
    if (cap && own.length < cap) return false
    return own.every(d => d.boat_note_passed)
  }

  // The list shows every CUSDEC that hasn't been released yet (blue-passed
  // or not) so any of them can be picked for a manual/ad-hoc check — but
  // Auto Trigger only ever runs on the blue (boat-note-passed) ones.
  const visibleCusdecs = cusdecs.filter(c => !c.export_release_passed)
  const eligible = visibleCusdecs.filter(boatNotePassed)
  const selected = visibleCusdecs.find(c => c.id === selectedId) || null

  // The CUSDEC's own tin_vat column (filled in when it was extracted/imported)
  // is the authoritative source — shipper_profiles.tin is only a fallback for
  // records that don't have one yet.
  async function resolveTin(c: CusdecRec): Promise<string> {
    if (c.tin_vat) return c.tin_vat
    const shipperName = (c.exporter || '').split('\n')[0].trim()
    try {
      const pr = await fetch(`/api/shipper-profile?shipper=${encodeURIComponent(shipperName)}`)
      return (await pr.json()).profile?.tin || ''
    } catch { return '' }
  }

  async function pickCusdec(id: string) {
    setSelectedId(id)
    const c = visibleCusdecs.find(x => x.id === id)
    if (!c) return
    const tin = await resolveTin(c)
    setForm({ officeCode: c.code || '', serial: 'E', cusdecNumber: cleanCusdecNumber(c.number), cusdecYear: yearOf(c.date), consigneeTIN: tin })
  }

  async function runOne(c: CusdecRec, tinOverride?: string) {
    const tin = tinOverride || await resolveTin(c)
    if (!tin) throw new Error(`No Company TIN found for CUSDEC E ${c.number} (not on the record or in the saved shipper profile) — enter it once manually first`)
    const res = await fetch('/api/export-release-check', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
      body: JSON.stringify({ officeCode: c.code, serial: 'E', cusdecNumber: cleanCusdecNumber(c.number), cusdecYear: yearOf(c.date), consigneeTIN: tin, cusdecId: c.id }),
    })
    const d = await res.json()
    if (!res.ok) throw new Error(d.error)
    return d
  }

  // Works with or without a CUSDEC selected from the list on the left — if
  // nothing's selected this is a pure ad-hoc check against whatever was
  // typed into the form (cusdecId omitted, so export-release-check.ts never
  // touches the database for it).
  async function manualTrigger() {
    setBusy(true); setError(''); setResult(null)
    try {
      // Manual trigger uses whatever TIN is currently in the form (so a
      // just-typed correction is respected), and remembers it for next time
      // — only when it's tied to a real CUSDEC record.
      if (form.consigneeTIN && selected) {
        const shipperName = (selected.exporter || '').split('\n')[0].trim()
        authHeader().then(h => fetch('/api/shipper-profile', {
          method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
          body: JSON.stringify({ shipper: shipperName, tin: form.consigneeTIN }),
        })).catch(() => {})
      }
      const res = await fetch('/api/export-release-check', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ ...form, cusdecId: selected?.id }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setResult(d)
      if (d.passed && selected) await load()
    } catch (e: any) { setError(e.message) }
    finally { setBusy(false) }
  }

  async function autoTrigger() {
    const pending = eligible.filter(c => !c.export_release_passed)
    if (!pending.length) { setAutoProgress('Nothing pending — every eligible CUSDEC already checked.'); return }
    setAutoBusy(true); setError('')
    let passedCount = 0
    for (let i = 0; i < pending.length; i++) {
      setAutoProgress(`Checking ${i + 1}/${pending.length} — E ${pending[i].number}...`)
      try {
        const d = await runOne(pending[i])
        if (d.passed) passedCount++
      } catch { /* keep going through the rest of the batch */ }
      await new Promise(r => setTimeout(r, 400))
    }
    await load()
    setAutoProgress(`Done — ${passedCount}/${pending.length} newly passed.`)
    setAutoBusy(false)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <div className="card">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <h2 className="font-semibold text-gray-900 text-sm">Select CUSDEC</h2>
          <button onClick={autoTrigger} disabled={autoBusy} className="btn-secondary flex items-center gap-2 text-xs">
            {autoBusy ? <Loader size={13} className="animate-spin"/> : <Zap size={13}/>}Auto Trigger (all pending)
          </button>
        </div>
        <div className="mb-2"><SchedulerControl panel="export_release" label="Auto-check"/></div>
        {nextVessel && (
          <div className="text-[11px] text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-md px-2 py-1.5 mb-3 flex items-center gap-1.5">
            <Ship size={10}/>
            <span>Next vessel: <strong>{nextVessel.vessel} {nextVessel.voyage}</strong> · ETB {nextVessel.etbStr} · Open {nextVessel.opening} → Close {nextVessel.closing}</span>
          </div>
        )}
        {autoProgress && <p className="text-xs text-gray-500 mb-2">{autoProgress}</p>}
        <p className="text-xs text-gray-400 mb-2">Blue-bordered = Boat Note passed, ready for Auto Trigger. Others can still be checked manually below.</p>
        <div className="space-y-1 max-h-96 overflow-y-auto">
          {visibleCusdecs.map(c => (
            <button key={c.id} onClick={() => pickCusdec(c.id)}
              className={`w-full text-left p-2.5 rounded-lg border-l-4 border text-xs ${
                selectedId === c.id ? 'bg-blue-50 border-blue-300' : 'border-gray-100 hover:bg-gray-50'
              } ${boatNotePassed(c) ? '!border-l-blue-400' : '!border-l-transparent'}`}>
              <p className="font-bold text-gray-800">E {c.number} {boatNotePassed(c) && <span className="text-blue-600 font-normal">· boat note passed</span>}</p>
              <p className="text-gray-600 truncate">{c.exporter?.slice(0, 40)}</p>
            </button>
          ))}
          {visibleCusdecs.length === 0 && <p className="text-xs text-gray-400 text-center py-6">No CUSDEC pending release</p>}
        </div>
        <OrphanedDataMonitor
          label="Non-Matched (no Company TIN on record)"
          count={eligible.filter(c => !c.tin_vat).length}
          items={eligible.filter(c => !c.tin_vat).map(c => ({ id: c.id, title: `E ${c.number}`, subtitle: c.exporter }))}
        />
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900 text-sm">Manual Trigger</h2>
          {lastTime && (
            <span className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-md px-2 py-0.5 flex items-center gap-1">
              <Clock size={10}/>
              {lastCusdec && <span className="font-mono font-bold">E {lastCusdec}</span>}
              {lastCusdec && <span className="text-amber-400">·</span>}
              {lastTime}
            </span>
          )}
        </div>
        <p className="text-xs text-gray-400 mb-3">
          {selected ? <>Checking E {selected.number} — <button onClick={() => { setSelectedId(''); setForm({ officeCode: '', serial: 'E', cusdecNumber: '', cusdecYear: '', consigneeTIN: '' }) }} className="text-blue-600 hover:underline">clear selection</button></>
            : 'No CUSDEC selected — type any values below to check ad-hoc (nothing gets saved to the database).'}
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-3">
          <Field label="Office Code"><input value={form.officeCode} onChange={e => setForm(f => ({ ...f, officeCode: e.target.value }))} className="input"/></Field>
          <Field label="Serial"><input value={form.serial} onChange={e => setForm(f => ({ ...f, serial: e.target.value }))} className="input"/></Field>
          <Field label="Cusdec Number"><input value={form.cusdecNumber} onChange={e => setForm(f => ({ ...f, cusdecNumber: e.target.value }))} className="input"/></Field>
          <Field label="Cusdec Year"><input value={form.cusdecYear} onChange={e => setForm(f => ({ ...f, cusdecYear: e.target.value }))} className="input"/></Field>
          <Field label="Company TIN"><input value={form.consigneeTIN} onChange={e => setForm(f => ({ ...f, consigneeTIN: e.target.value }))} className="input"/></Field>
        </div>
        <button onClick={manualTrigger} disabled={busy || !form.officeCode || !form.cusdecNumber || !form.cusdecYear || !form.consigneeTIN}
          className="btn-primary flex items-center gap-2">
          {busy ? <Loader size={14} className="animate-spin"/> : <Search size={14}/>}Check Status
        </button>
        {error && <p className="text-xs text-red-600 mt-3 flex items-center gap-1"><AlertTriangle size={13}/>{error}</p>}
        {result && !result.found && (
          <p className="text-xs text-amber-600 mt-3 flex items-center gap-1"><AlertTriangle size={13}/>{result.message}</p>
        )}
        {result?.found && (
          <>
            <p className={`text-xs font-semibold mt-3 ${result.passed ? 'text-green-600' : 'text-amber-600'}`}>
              {result.passed ? '✓ Export Release passed' : result.passed === false ? '✗ Not passed yet' : '⚠ Could not determine pass/fail — check the raw text below'}
            </p>
            <pre className="mt-2 border border-gray-200 rounded-lg p-3 text-xs bg-gray-50 whitespace-pre-wrap max-h-72 overflow-y-auto">{result.text}</pre>
          </>
        )}
      </div>
    </div>
  )
}

// ── Vessel Triggers ────────────────────────────────────────────────────────
interface VesselRow { id: string; terminal: string; vessel: string; voyage: string; opening_time: string; closing_time: string; etb: string; last_update: string }
type VesselSortKey = keyof VesselRow
type SortDir = 'asc' | 'desc'

function sortVessel(rows: VesselRow[], key: VesselSortKey, dir: SortDir) {
  return [...rows].sort((a, b) => {
    const av = (a[key] || '').toString().toLowerCase()
    const bv = (b[key] || '').toString().toLowerCase()
    return dir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av)
  })
}

function VesselTriggerPanel() {
  const [items, setItems] = useState<VesselRow[]>([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [sortKey, setSortKey] = useState<VesselSortKey>('etb')
  const [sortDir, setSortDir] = useState<SortDir>('asc')
  const [syncing, setSyncing] = useState(false)
  const [status, setStatus] = useState('')
  // The mount-only poll interval below closes over `load` as it was at mount
  // time — without this ref it would keep re-fetching with search='' forever
  // once the interval is set up, silently wiping out an active search result
  // every 15s. The ref always has the current value; `search` itself still
  // drives the input as normal.
  const searchRef = useRef(search)
  useEffect(() => { searchRef.current = search }, [search])

  async function load(silent = false) {
    if (!silent) setLoading(true)
    try {
      const params = new URLSearchParams()
      if (searchRef.current) params.set('search', searchRef.current)
      const res = await fetch(`/api/vessel-triggers?${params.toString()}`, { headers: await authHeader() })
      const d = await res.json()
      if (res.ok) setItems(d.items || [])
    } finally { if (!silent) setLoading(false) }
  }
  useEffect(() => {
    load()
    // Live — reflects a sync that just ran (manual or the hourly cron ping)
    // without a manual refresh.
    const t = setInterval(() => load(true), 15000)
    return () => clearInterval(t)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  async function triggerNow() {
    setSyncing(true); setStatus('')
    try {
      const res = await fetch('/api/vessel-trigger-sync', { method: 'POST', headers: await authHeader() })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      setStatus(`✓ Synced — ${d.fetched} fetched, ${d.inserted} new, ${d.updated} updated, ${d.unchanged} unchanged`)
      load()
    } catch (e: any) {
      setStatus(`✗ ${e.message}`)
    } finally {
      setSyncing(false)
    }
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <h2 className="font-semibold text-gray-900 text-sm">Vessel Schedule (Terminal / Vessel / Voyage / Opening / Closing / ETB)</h2>
        <button onClick={triggerNow} disabled={syncing} className="btn-secondary flex items-center gap-2 text-xs">
          {syncing ? <Loader size={13} className="animate-spin"/> : <Zap size={13}/>}Trigger Now
        </button>
      </div>
      <div className="mb-3"><SchedulerControl panel="vessel_trigger" label="Sync"/></div>
      {status && <p className={`text-xs mb-3 font-medium ${status.startsWith('✓') ? 'text-green-600' : 'text-red-600'}`}>{status}</p>}
      <div className="flex items-center gap-2 mb-3">
        <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && load()}
          placeholder="Search vessel, voyage, or terminal..." className="input"/>
        <button onClick={() => load()} className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs text-white flex-shrink-0" style={{ background: '#1B3A5C' }}>
          <Search size={12}/> Search
        </button>
      </div>
      {loading ? (
        <div className="flex justify-center py-8"><Loader size={18} className="animate-spin text-gray-400"/></div>
      ) : items.length === 0 ? (
        <p className="text-xs text-gray-400 text-center py-6">No vessel schedule data yet — click Trigger Now to sync</p>
      ) : (
        <div className="overflow-x-auto max-h-[28rem] overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="bg-gray-50 sticky top-0"><tr>
              {([['terminal','Terminal'],['vessel','Vessel'],['voyage','Voyage'],['opening_time','Opening'],['closing_time','Closing'],['etb','ETB'],['last_update','Last Updated']] as [VesselSortKey, string][]).map(([k, label]) => (
                <th key={k} onClick={() => { if (sortKey === k) setSortDir(d => d === 'asc' ? 'desc' : 'asc'); else { setSortKey(k); setSortDir('asc') } }}
                  className="text-left px-2 py-1.5 text-gray-500 font-medium cursor-pointer select-none hover:text-gray-800 whitespace-nowrap">
                  {label}{sortKey === k ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
                </th>
              ))}
            </tr></thead>
            <tbody>
              {sortVessel(items, sortKey, sortDir).map(r => (
                <tr key={r.id} className="border-t border-gray-50">
                  <td className="px-2 py-1.5 text-gray-800">{r.terminal}</td>
                  <td className="px-2 py-1.5 text-gray-800 font-medium">{r.vessel}</td>
                  <td className="px-2 py-1.5 text-gray-600">{r.voyage}</td>
                  <td className="px-2 py-1.5 text-gray-600">{r.opening_time}</td>
                  <td className="px-2 py-1.5 text-gray-600">{r.closing_time}</td>
                  <td className="px-2 py-1.5 text-gray-600">{r.etb}</td>
                  <td className="px-2 py-1.5 text-gray-400">{r.last_update}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

// ── Conflict Review Panel ─────────────────────────────────────────────────
interface ConflictDoc { id: string; file_name: string; drive_url?: string; doc_type?: string; reason?: string; extracted_data?: Record<string, string> }
interface Conflict { id: string; old_doc_id: string; new_doc_id: string; picked_by: string; picked_by_name: string; doc_type: string; ref_key: string; resolved: boolean; resolution?: string; created_at: string; old_doc?: ConflictDoc; new_doc?: ConflictDoc }

function ConflictReviewPanel() {
  const [conflicts, setConflicts] = useState<Conflict[]>([])
  const [loading, setLoading] = useState(false)
  const [showResolved, setShowResolved] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [msg, setMsg] = useState('')

  async function load() {
    setLoading(true); setMsg('')
    try {
      const r = await fetch(`/api/document-conflicts?resolved=${showResolved}`, { headers: await authHeader() })
      if (r.ok) { const d = await r.json(); setConflicts(d.conflicts || []) }
      else { const d = await r.json(); setMsg(`✗ ${d.error}`) }
    } catch (e: any) { setMsg(`✗ ${e.message}`) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [showResolved])

  async function resolve(conflictId: string, resolution: 'keep_old' | 'use_new' | 'both') {
    setBusyId(conflictId); setMsg('')
    try {
      const r = await fetch('/api/document-conflicts', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ conflict_id: conflictId, resolution }),
      })
      if (r.ok) { setMsg('✓ Resolved'); load() }
      else { const d = await r.json(); setMsg(`✗ ${d.error}`) }
    } catch (e: any) { setMsg(`✗ ${e.message}`) }
    finally { setBusyId(null) }
  }

  const typeColor: Record<string, string> = { cusdec: '#1B3A5C', cdn: '#22A87A', barcode: '#f59e0b', boat_note: '#3b82f6', party_copy: '#8b5cf6', bill: '#ef4444' }

  return (
    <div className="max-w-4xl">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="font-semibold text-gray-900 flex items-center gap-2"><GitMerge size={16}/>Conflict Review</h2>
          <p className="text-xs text-gray-500 mt-0.5">When a new document version is uploaded for an already-picked reference, it appears here for admin review.</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 text-xs text-gray-500 cursor-pointer">
            <input type="checkbox" checked={showResolved} onChange={e => setShowResolved(e.target.checked)}/>
            Show resolved
          </label>
          <button onClick={load} className="btn-secondary text-xs flex items-center gap-1"><RefreshCw size={12}/>Refresh</button>
        </div>
      </div>

      {msg && <p className={`text-sm mb-4 font-medium ${msg.startsWith('✓') ? 'text-green-600' : 'text-red-600'}`}>{msg}</p>}

      {loading ? (
        <div className="flex justify-center py-12"><Loader size={20} className="animate-spin text-gray-400"/></div>
      ) : conflicts.length === 0 ? (
        <div className="card text-center py-10 text-gray-400">
          <GitMerge size={28} className="mx-auto mb-2 text-gray-200"/>
          <p className="text-sm">{showResolved ? 'No resolved conflicts' : 'No pending conflicts — all clear!'}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {conflicts.map(c => {
            const busy = busyId === c.id
            const color = typeColor[c.doc_type] || '#6b7280'
            return (
              <div key={c.id} className="card border-l-4" style={{ borderLeftColor: color }}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="text-sm font-semibold text-gray-800 flex items-center gap-2">
                      <span className="text-[11px] font-normal px-2 py-0.5 rounded-full text-white" style={{ background: color }}>
                        {c.doc_type?.toUpperCase() || 'DOC'}
                      </span>
                      {c.ref_key || 'Unknown reference'}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Picked by <span className="font-medium text-gray-700">{c.picked_by_name || 'unknown user'}</span>
                      {' · '}
                      {new Date(c.created_at).toLocaleString('en-GB', { timeZone: 'Asia/Colombo', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  {c.resolved && (
                    <span className="text-[11px] px-2 py-1 rounded-full bg-green-100 text-green-700 font-medium">
                      {c.resolution?.replace('_', ' ')} ✓
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-gray-50 rounded-xl p-3">
                    <p className="text-[11px] font-bold text-gray-500 mb-1">OLD (Picked)</p>
                    <p className="text-xs text-gray-700 truncate">{c.old_doc?.file_name || c.old_doc_id}</p>
                    {c.old_doc?.drive_url && (
                      <a href={c.old_doc.drive_url} target="_blank" rel="noopener noreferrer"
                        className="text-[11px] text-blue-600 flex items-center gap-1 mt-1 hover:underline">
                        <ExternalLink size={10}/>View PDF
                      </a>
                    )}
                    {c.old_doc?.extracted_data && (
                      <div className="mt-1.5 space-y-0.5">
                        {Object.entries(c.old_doc.extracted_data).slice(0, 4).map(([k, v]) => (
                          <p key={k} className="text-[10px] text-gray-400">{k}: <span className="text-gray-600">{v}</span></p>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="bg-orange-50 rounded-xl p-3 border border-orange-100">
                    <p className="text-[11px] font-bold text-orange-500 mb-1">NEW (Updated)</p>
                    <p className="text-xs text-gray-700 truncate">{c.new_doc?.file_name || c.new_doc_id}</p>
                    {c.new_doc?.drive_url && (
                      <a href={c.new_doc.drive_url} target="_blank" rel="noopener noreferrer"
                        className="text-[11px] text-blue-600 flex items-center gap-1 mt-1 hover:underline">
                        <ExternalLink size={10}/>View PDF
                      </a>
                    )}
                    {c.new_doc?.extracted_data && (
                      <div className="mt-1.5 space-y-0.5">
                        {Object.entries(c.new_doc.extracted_data).slice(0, 4).map(([k, v]) => (
                          <p key={k} className="text-[10px] text-gray-400">{k}: <span className="text-gray-600">{v}</span></p>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {!c.resolved && (
                  <div className="flex gap-2">
                    <button onClick={() => resolve(c.id, 'keep_old')} disabled={busy}
                      className="flex-1 py-2 rounded-lg text-xs font-medium border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
                      {busy ? <Loader size={12} className="animate-spin inline"/> : null} Keep Old
                    </button>
                    <button onClick={() => resolve(c.id, 'use_new')} disabled={busy}
                      className="flex-1 py-2 rounded-lg text-xs font-medium text-white disabled:opacity-40"
                      style={{ background: '#22A87A' }}>
                      Use New Version
                    </button>
                    <button onClick={() => resolve(c.id, 'both')} disabled={busy}
                      className="flex-1 py-2 rounded-lg text-xs font-medium text-white disabled:opacity-40"
                      style={{ background: '#1B3A5C' }}>
                      Keep Both
                    </button>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ── CDN Approval Panel (admin) ─────────────────────────────────────────────
// CDNs uploaded are held in pending_admin_approval = true until admin approves
// here. Only approved CDNs count toward the CUSDEC's CAP.
interface PendingCdn { id: string; code: string; cusdec_number: string; container_no: string; vessel: string; voyage: string; seal_no: string; cdn_no: string; uploaded_at: string }
function CdnApprovalPanel() {
  const [cdns, setCdns] = useState<PendingCdn[]>([])
  const [loading, setLoading] = useState(false)
  const [approvingId, setApprovingId] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/cdn-approval', { headers: await authHeader() })
      const d = await res.json()
      if (res.ok) setCdns(d.cdns || [])
    } finally { setLoading(false) }
  }
  useEffect(() => { load() }, []) // eslint-disable-line

  async function approve(id: string) {
    setApprovingId(id)
    try {
      const res = await fetch('/api/cdn-approval', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ cdn_id: id }),
      })
      if (res.ok) setCdns(prev => prev.filter(c => c.id !== id))
    } finally { setApprovingId(null) }
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="font-semibold text-gray-900 text-sm flex items-center gap-2"><CheckSquare size={15} className="text-blue-600"/>CDN Approval</h2>
          <p className="text-xs text-gray-400 mt-0.5">Approve uploaded CDNs to count them toward the CUSDEC&apos;s CAP. Unapproved CDNs do not count.</p>
        </div>
        <button onClick={load} disabled={loading} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs border border-gray-200 hover:bg-gray-50 disabled:opacity-50">
          {loading ? <Loader size={12} className="animate-spin"/> : <RefreshCw size={12}/>} Refresh
        </button>
      </div>
      {loading && cdns.length === 0 ? (
        <div className="flex justify-center py-8"><Loader size={18} className="animate-spin text-gray-400"/></div>
      ) : cdns.length === 0 ? (
        <p className="text-xs text-gray-400 text-center py-8">No CDNs pending approval</p>
      ) : (
        <div className="space-y-2">
          {cdns.map(c => (
            <div key={c.id} className="flex items-center justify-between gap-3 border border-amber-100 bg-amber-50 rounded-lg p-3 text-xs">
              <div className="min-w-0 space-y-0.5">
                <p className="font-semibold text-gray-900">Container: {c.container_no || '—'} · CDN: {c.cdn_no || '—'}</p>
                <p className="text-gray-500">CUSDEC: {c.cusdec_number || '—'} · Code: {c.code || '—'}</p>
                <p className="text-gray-400">Vessel: {c.vessel || '—'} / {c.voyage || '—'} · Seal: {c.seal_no || '—'}</p>
                <p className="text-gray-400">Uploaded: {c.uploaded_at ? new Date(c.uploaded_at).toLocaleString('en-GB') : '—'}</p>
              </div>
              <button onClick={() => approve(c.id)} disabled={approvingId === c.id}
                className="flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-white disabled:opacity-50" style={{ background: '#22A87A' }}>
                {approvingId === c.id ? <Loader size={12} className="animate-spin"/> : <CheckSquare size={12}/>}
                Approve
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ── 4. System Logic & Integration Notes ───────────────────────────────────
interface SystemNote { id: string; title: string; content: string; updated_at: string }
function SystemNotes() {
  const [notes, setNotes] = useState<SystemNote[]>([])
  const [editId, setEditId] = useState<string | null>(null)
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')

  async function load() {
    const res = await fetch('/api/system-notes', { headers: await authHeader() })
    const d = await res.json()
    if (res.ok) setNotes(d.notes || [])
  }
  // Live — a note someone else saved shows up here without a refresh; an
  // in-progress edit (title/content/editId below) is untouched by this since
  // it's separate state from the notes list itself.
  useEffect(() => {
    load()
    const t = setInterval(load, 30000)
    return () => clearInterval(t)
  }, [])

  async function save() {
    if (!title.trim()) return
    await fetch('/api/system-notes', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
      body: JSON.stringify({ id: editId, title, content }),
    })
    setTitle(''); setContent(''); setEditId(null)
    load()
  }
  function edit(n: SystemNote) { setEditId(n.id); setTitle(n.title); setContent(n.content || '') }
  async function remove(id: string) {
    if (!confirm('Delete this note?')) return
    await fetch(`/api/system-notes?id=${id}`, { method: 'DELETE', headers: await authHeader() })
    if (editId === id) { setEditId(null); setTitle(''); setContent('') }
    load()
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <div className="card">
        <h2 className="font-semibold text-gray-900 text-sm mb-3">{editId ? 'Edit Note' : 'New Note'}</h2>
        <div className="space-y-3">
          <Field label="Title"><input value={title} onChange={e => setTitle(e.target.value)} className="input"/></Field>
          <Field label="Details"><textarea value={content} onChange={e => setContent(e.target.value)} rows={10} className="input"/></Field>
        </div>
        <div className="flex gap-2 mt-4">
          <button onClick={save} className="btn-primary flex items-center gap-2"><Save size={14}/>{editId ? 'Update' : 'Add'} Note</button>
          {editId && <button onClick={() => { setEditId(null); setTitle(''); setContent('') }} className="btn-secondary">Cancel</button>}
        </div>
      </div>
      <div className="card">
        <h2 className="font-semibold text-gray-900 text-sm mb-3">Saved Notes</h2>
        <div className="space-y-2 max-h-[32rem] overflow-y-auto">
          {notes.map(n => (
            <div key={n.id} className="border border-gray-100 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-sm text-gray-800">{n.title}</p>
                <div className="flex gap-2">
                  <button onClick={() => edit(n)} className="text-gray-400 hover:text-blue-600 text-xs">Edit</button>
                  <button onClick={() => remove(n.id)} className="text-gray-300 hover:text-red-500"><Trash2 size={13}/></button>
                </div>
              </div>
              {n.content && <p className="text-xs text-gray-500 mt-1 whitespace-pre-wrap">{n.content}</p>}
            </div>
          ))}
          {notes.length === 0 && <p className="text-xs text-gray-400 text-center py-6">No notes yet</p>}
        </div>
      </div>
    </div>
  )
}

// ── PDF Editor ─────────────────────────────────────────────────────────────
// Client-side PDF annotator. Renders pages server-side (mupdf), lets the user
// place text/highlight overlays on a canvas, then uses pdf-lib client-side to
// burn those annotations into the PDF before download. Nothing is uploaded to
// Drive — the edited file goes straight to the user's Downloads folder.

interface PdfAnnotation {
  id: string
  page: number
  // position as fractions of the rendered image (0–1), matched back to PDF
  // units on download based on the rendered image dimensions
  xFrac: number
  yFrac: number
  type: 'text' | 'highlight' | 'whiteout'
  text: string
  fontSize: number
  color: string
  width: number   // fraction of page width — only used for highlight rects
  height: number  // fraction of page height — only used for highlight rects
}

// Text span extracted by PDF.js — cx/cy/cw/ch/cFontSize in canvas pixels,
// pdfX/pdfY/pdfW/pdfFontSize in PDF points for pdf-lib burn step.
interface PdfTextItem {
  id: string; page: number
  cx: number; cy: number; cw: number; ch: number; cFontSize: number
  pdfX: number; pdfY: number; pdfW: number; pdfFontSize: number
  text: string
}

const PDF_SCALE = 1.5 // render scale — higher = sharper but heavier

function PdfEditorPanel() {
  const fileRef = useRef<HTMLInputElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pdfDocRef = useRef<any>(null)
  const viewportRef = useRef<{ width: number; height: number } | null>(null)
  const renderTaskRef = useRef<any>(null)

  const [origBase64, setOrigBase64] = useState('')
  const [numPages, setNumPages] = useState(0)
  const [currentPage, setCurrentPage] = useState(0)
  const [loading, setLoading] = useState(false)
  const [canvasReady, setCanvasReady] = useState(false)
  const [tool, setTool] = useState<'text' | 'highlight' | 'whiteout'>('text')
  const [annotations, setAnnotations] = useState<PdfAnnotation[]>([])
  const [pendingInput, setPendingInput] = useState<{ xFrac: number; yFrac: number } | null>(null)
  const [pendingText, setPendingText] = useState('')
  const [fontSize, setFontSize] = useState(12)
  const [color, setColor] = useState('#000000')
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null)
  const [downloading, setDownloading] = useState(false)
  const [status, setStatus] = useState('')
  const [textItems, setTextItems] = useState<PdfTextItem[]>([])
  const [editedTexts, setEditedTexts] = useState<Record<string, string>>({})
  const [editingId, setEditingId] = useState<string | null>(null)

  const pageAnnotations = annotations.filter(a => a.page === currentPage)
  const pageTextItems = textItems.filter(t => t.page === currentPage)

  async function handleFile(file: File) {
    setStatus('Loading…'); setLoading(true); setCanvasReady(false)
    setAnnotations([]); setTextItems([]); setEditedTexts({}); setEditingId(null)
    setCurrentPage(0); setPendingInput(null)
    try {
      const ab = await file.arrayBuffer()
      const bytes = new Uint8Array(ab)
      // Store as base64 for download + openInSejda
      let bin = ''; bytes.forEach(b => { bin += String.fromCharCode(b) })
      setOrigBase64(btoa(bin))

      const pdfjs = await import('pdfjs-dist')
      pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`
      const doc = await pdfjs.getDocument({ data: bytes }).promise
      pdfDocRef.current = doc
      setNumPages(doc.numPages)
      await renderPage(doc, 0, pdfjs)
    } catch (e: any) {
      setStatus(`Error: ${e.message}`)
    } finally {
      setLoading(false)
    }
  }

  async function renderPage(doc: any, pageIndex: number, pdfjsLib?: any) {
    setLoading(true); setCanvasReady(false); setStatus(`Page ${pageIndex + 1}…`)
    setEditingId(null); setPendingInput(null)
    try {
      if (!pdfjsLib) pdfjsLib = await import('pdfjs-dist')
      const page = await doc.getPage(pageIndex + 1)
      const vp = page.getViewport({ scale: PDF_SCALE })
      viewportRef.current = { width: vp.width, height: vp.height }

      const canvas = canvasRef.current!
      canvas.width = vp.width
      canvas.height = vp.height
      const ctx = canvas.getContext('2d')!

      if (renderTaskRef.current) { try { renderTaskRef.current.cancel() } catch {} }
      const task = page.render({ canvasContext: ctx, viewport: vp })
      renderTaskRef.current = task
      await task.promise

      // Extract text items using PDF.js — positions in canvas px and PDF pts
      const tc = await page.getTextContent()
      const items: PdfTextItem[] = []
      tc.items.forEach((it: any, i: number) => {
        const str = (it.str || '').trim()
        if (!str) return
        // tx = item transform applied to viewport → canvas-space coords
        const tx = pdfjsLib.Util.transform(vp.transform, it.transform)
        const cFontSize = Math.abs(tx[0]) || Math.abs(tx[3]) || 10
        const cx = tx[4]
        const cy = tx[5] - cFontSize                        // baseline → top
        const cw = (it.width || 0) * PDF_SCALE || cFontSize * str.length * 0.55
        const ch = (it.height || 0) * PDF_SCALE || cFontSize

        // PDF-native coords for pdf-lib (x from left, y from bottom)
        const pdfFontSize = Math.sqrt(it.transform[0] ** 2 + it.transform[1] ** 2) || 10

        items.push({
          id: `p${pageIndex}_${i}`,
          page: pageIndex,
          cx, cy, cw, ch, cFontSize,
          pdfX: it.transform[4], pdfY: it.transform[5],
          pdfW: it.width || pdfFontSize * str.length * 0.55,
          pdfFontSize,
          text: it.str,
        })
      })
      setTextItems(prev => [...prev.filter(t => t.page !== pageIndex), ...items])
      setCanvasReady(true)
      setStatus('')
    } catch (e: any) {
      if ((e as any)?.name !== 'RenderingCancelledException') setStatus(`Error: ${e.message}`)
    } finally {
      setLoading(false)
    }
  }

  async function goToPage(idx: number) {
    if (!pdfDocRef.current || idx < 0 || idx >= numPages) return
    setCurrentPage(idx)
    await renderPage(pdfDocRef.current, idx)
  }

  function canvasCoords(e: React.MouseEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!
    const rect = canvas.getBoundingClientRect()
    // map display pixels → canvas pixels
    const sx = canvas.width / rect.width
    const sy = canvas.height / rect.height
    const x = (e.clientX - rect.left) * sx
    const y = (e.clientY - rect.top) * sy
    const vp = viewportRef.current!
    return { xFrac: x / vp.width, yFrac: y / vp.height }
  }

  function handleCanvasClick(e: React.MouseEvent<HTMLCanvasElement>) {
    if (tool !== 'text') return
    const { xFrac, yFrac } = canvasCoords(e)
    setPendingInput({ xFrac, yFrac })
    setPendingText('')
  }

  function commitText() {
    if (!pendingInput || !pendingText.trim()) { setPendingInput(null); return }
    setAnnotations(prev => [...prev, {
      id: `${Date.now()}`, page: currentPage,
      xFrac: pendingInput.xFrac, yFrac: pendingInput.yFrac,
      type: 'text', text: pendingText.trim(), fontSize, color, width: 0, height: 0,
    }])
    setPendingInput(null); setPendingText('')
  }

  function handleMouseDown(e: React.MouseEvent<HTMLCanvasElement>) {
    if (tool !== 'highlight' && tool !== 'whiteout') return
    const rect = canvasRef.current!.getBoundingClientRect()
    setDragStart({ x: e.clientX - rect.left, y: e.clientY - rect.top })
  }

  function handleMouseUp(e: React.MouseEvent<HTMLCanvasElement>) {
    if ((tool !== 'highlight' && tool !== 'whiteout') || !dragStart) return
    const rect = canvasRef.current!.getBoundingClientRect()
    const x2 = e.clientX - rect.left; const y2 = e.clientY - rect.top
    const x = Math.min(dragStart.x, x2); const y = Math.min(dragStart.y, y2)
    const w = Math.abs(x2 - dragStart.x); const h = Math.abs(y2 - dragStart.y)
    if (w > 5 && h > 5) {
      setAnnotations(prev => [...prev, {
        id: `${Date.now()}`, page: currentPage,
        xFrac: x / rect.width, yFrac: y / rect.height,
        type: tool as 'highlight' | 'whiteout', text: '', fontSize: 0, color: '',
        width: w / rect.width, height: h / rect.height,
      }])
    }
    setDragStart(null)
  }

  function removeAnnotation(id: string) { setAnnotations(prev => prev.filter(a => a.id !== id)) }

  async function downloadEdited() {
    if (!origBase64) return
    setDownloading(true); setStatus('Preparing…')
    try {
      const { PDFDocument, rgb, StandardFonts } = await import('pdf-lib')
      const bytes = Uint8Array.from(atob(origBase64), c => c.charCodeAt(0))
      const pdfDoc = await PDFDocument.load(bytes)
      const font = await pdfDoc.embedFont(StandardFonts.Helvetica)
      const pdfPages = pdfDoc.getPages()

      for (const ann of annotations) {
        const pg = pdfPages[ann.page]; if (!pg) continue
        const pdfW = pg.getWidth(); const pdfH = pg.getHeight()
        const hex = ann.color || '#000000'
        const r = parseInt(hex.slice(1,3),16)/255, g = parseInt(hex.slice(3,5),16)/255, b = parseInt(hex.slice(5,7),16)/255
        if (ann.type === 'text') {
          pg.drawText(ann.text, { x: ann.xFrac * pdfW, y: (1 - ann.yFrac) * pdfH - ann.fontSize, size: ann.fontSize, font, color: rgb(r,g,b) })
        } else if (ann.type === 'highlight') {
          pg.drawRectangle({ x: ann.xFrac*pdfW, y:(1-ann.yFrac-ann.height)*pdfH, width:ann.width*pdfW, height:ann.height*pdfH, color:rgb(1,1,0), opacity:0.35 })
        } else if (ann.type === 'whiteout') {
          pg.drawRectangle({ x: ann.xFrac*pdfW, y:(1-ann.yFrac-ann.height)*pdfH, width:ann.width*pdfW, height:ann.height*pdfH, color:rgb(1,1,1), opacity:1 })
        }
      }

      // Burn edited text: whiteout original area, draw new text at same PDF coords
      for (const [id, newText] of Object.entries(editedTexts)) {
        const item = textItems.find(t => t.id === id); if (!item) continue
        const pg = pdfPages[item.page]; if (!pg) continue
        pg.drawRectangle({
          x: item.pdfX - 1, y: item.pdfY - 2,
          width: Math.max(item.pdfW, newText.length * item.pdfFontSize * 0.55) + 4,
          height: item.pdfFontSize + 4,
          color: rgb(1,1,1), opacity: 1,
        })
        pg.drawText(newText, { x: item.pdfX, y: item.pdfY, size: item.pdfFontSize, font, color: rgb(0,0,0) })
      }

      const edited = await pdfDoc.save()
      const blob = new Blob([edited.buffer as ArrayBuffer], { type: 'application/pdf' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a'); a.href = url; a.download = 'edited.pdf'; a.click()
      URL.revokeObjectURL(url)
      setStatus('Downloaded!')
    } catch (e: any) {
      setStatus(`Error: ${e.message}`)
    } finally {
      setDownloading(false)
    }
  }

  function clearAll() {
    pdfDocRef.current = null; viewportRef.current = null
    setOrigBase64(''); setNumPages(0); setCurrentPage(0)
    setAnnotations([]); setTextItems([]); setEditedTexts({}); setEditingId(null)
    setPendingInput(null); setPendingText(''); setStatus(''); setCanvasReady(false); setLoading(false)
    if (fileRef.current) fileRef.current.value = ''
  }

  return (
    <div className="space-y-4 max-w-4xl">
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900 text-sm flex items-center gap-2">
            <FilePen size={15} className="text-indigo-500"/>PDF Editor
          </h2>
          {origBase64 && (
            <button onClick={clearAll} className="flex items-center gap-1 text-xs text-gray-400 hover:text-red-500">
              <X size={12}/>Clear
            </button>
          )}
        </div>

        {!origBase64 ? (
          <div
            className="border-2 border-dashed border-gray-200 rounded-xl p-10 text-center cursor-pointer hover:border-indigo-300 transition-colors"
            onClick={() => fileRef.current?.click()}
            onDragOver={e => e.preventDefault()}
            onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) handleFile(f) }}>
            <Upload size={24} className="mx-auto mb-2 text-gray-300"/>
            <p className="text-sm text-gray-500">Click or drag a PDF to edit</p>
            <p className="text-xs text-gray-400 mt-1">Click existing text to edit · Highlight · Whiteout · Add new text</p>
            <input ref={fileRef} type="file" accept="application/pdf" className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f) }}/>
          </div>
        ) : (
          <>
            {/* Toolbar */}
            <div className="flex items-center gap-3 mb-3 flex-wrap">
              <div className="flex gap-1 bg-gray-100 p-0.5 rounded-lg">
                <button onClick={() => setTool('text')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${tool === 'text' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'}`}>
                  <Type size={12}/>Text
                </button>
                <button onClick={() => setTool('highlight')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${tool === 'highlight' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'}`}>
                  <Highlighter size={12}/>Highlight
                </button>
                <button onClick={() => setTool('whiteout')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${tool === 'whiteout' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'}`}>
                  <Eraser size={12}/>Whiteout
                </button>
              </div>

              {tool === 'text' && (
                <>
                  <label className="flex items-center gap-1.5 text-xs text-gray-600">
                    Size
                    <input type="number" min={6} max={72} value={fontSize}
                      onChange={e => setFontSize(Number(e.target.value) || 12)}
                      className="w-14 border border-gray-200 rounded px-2 py-1 text-xs focus:outline-none"/>
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-gray-600">
                    Color
                    <input type="color" value={color} onChange={e => setColor(e.target.value)}
                      className="w-7 h-7 rounded border border-gray-200 cursor-pointer p-0.5"/>
                  </label>
                </>
              )}

              <div className="flex-1"/>

              <div className="flex items-center gap-2">
                <button onClick={() => goToPage(currentPage - 1)} disabled={currentPage === 0 || loading}
                  className="p-1.5 rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50 disabled:opacity-40">
                  <ChevronLeft size={14}/>
                </button>
                <span className="text-xs text-gray-600">
                  Page {currentPage + 1} / {numPages || '?'}
                </span>
                <button onClick={() => goToPage(currentPage + 1)} disabled={currentPage >= numPages - 1 || loading}
                  className="p-1.5 rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50 disabled:opacity-40">
                  <ChevronRight size={14}/>
                </button>
              </div>

              <button onClick={downloadEdited} disabled={downloading || loading}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white disabled:opacity-50"
                style={{ background: '#1B3A5C' }}>
                {downloading ? <Loader size={12} className="animate-spin"/> : <Download size={12}/>}
                Download
              </button>
            </div>

            {status && (
              <p className="text-xs text-indigo-600 mb-2 flex items-center gap-1">
                {(loading || downloading) && <Loader size={11} className="animate-spin"/>}{status}
              </p>
            )}

            {/* Canvas + overlay */}
            <div className="relative inline-block border border-gray-200 rounded-xl select-none"
              style={{ maxWidth: '100%', overflow: 'visible' }}>
              {loading && !canvasReady && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-50 rounded-xl z-10 min-h-[24rem]">
                  <Loader size={24} className="animate-spin text-gray-400"/>
                </div>
              )}

              {/* PDF.js renders directly into this canvas */}
              <canvas
                ref={canvasRef}
                style={{
                  display: 'block', maxWidth: '100%', borderRadius: 'inherit',
                  cursor: tool === 'text' ? 'text' : tool === 'whiteout' ? 'cell' : 'crosshair',
                  visibility: canvasReady ? 'visible' : 'hidden',
                }}
                onClick={handleCanvasClick}
                onMouseDown={handleMouseDown}
                onMouseUp={handleMouseUp}
              />

              {/* Overlay — same logical size as canvas via percentage coords */}
              {canvasReady && (
                <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 2, containerType: 'inline-size' } as React.CSSProperties}>

                  {/* User-added annotations (text labels, highlights, whiteouts) */}
                  {pageAnnotations.map(ann => {
                    if (ann.type === 'text') return (
                      <div key={ann.id} style={{ position: 'absolute', left: `${ann.xFrac*100}%`, top: `${ann.yFrac*100}%`, pointerEvents: 'auto', display: 'flex', alignItems: 'flex-start', gap: 2, zIndex: 3 }}>
                        <span style={{ fontSize: ann.fontSize * 0.75, color: ann.color, fontFamily: 'Helvetica, Arial, sans-serif', whiteSpace: 'pre', lineHeight: 1.2, userSelect: 'none' }}>{ann.text}</span>
                        <button onClick={() => removeAnnotation(ann.id)} style={{ background: '#ef4444', color: '#fff', border: 'none', borderRadius: 3, padding: '1px 3px', fontSize: 9, cursor: 'pointer', lineHeight: 1 }}>×</button>
                      </div>
                    )
                    if (ann.type === 'highlight') return <div key={ann.id} style={{ position: 'absolute', left: `${ann.xFrac*100}%`, top: `${ann.yFrac*100}%`, width: `${ann.width*100}%`, height: `${ann.height*100}%`, background: '#FFFF00', opacity: 0.4, pointerEvents: 'none' }}/>
                    if (ann.type === 'whiteout') return <div key={ann.id} style={{ position: 'absolute', left: `${ann.xFrac*100}%`, top: `${ann.yFrac*100}%`, width: `${ann.width*100}%`, height: `${ann.height*100}%`, background: '#fff', border: '1.5px dashed #9ca3af', pointerEvents: 'none' }}/>
                    return null
                  })}

                  {/* Existing PDF text — transparent clickable rects; click → edit in place */}
                  {pageTextItems.map(item => {
                    const vp = viewportRef.current!
                    const xPct = `${item.cx / vp.width * 100}%`
                    const yPct = `${item.cy / vp.height * 100}%`
                    const wPct = `${item.cw / vp.width * 100}%`
                    const hPct = `${item.ch / vp.height * 100}%`
                    const fontCqw = `${item.cFontSize / vp.width * 100}cqw`
                    const isEdited = item.id in editedTexts
                    const isEditing = editingId === item.id

                    if (isEditing) return (
                      <div key={item.id} style={{ position: 'absolute', left: xPct, top: yPct, minWidth: wPct, zIndex: 20, pointerEvents: 'auto' }}>
                        <input autoFocus
                          defaultValue={editedTexts[item.id] ?? item.text}
                          onKeyDown={e => {
                            if (e.key === 'Enter' || e.key === 'Escape') {
                              const v = (e.target as HTMLInputElement).value
                              if (e.key === 'Enter' && v !== item.text) setEditedTexts(p => ({ ...p, [item.id]: v }))
                              else if (e.key === 'Enter') { const n = { ...editedTexts }; delete n[item.id]; setEditedTexts(n) }
                              setEditingId(null)
                            }
                          }}
                          onBlur={e => {
                            const v = e.target.value
                            if (v !== item.text) setEditedTexts(p => ({ ...p, [item.id]: v }))
                            else { const n = { ...editedTexts }; delete n[item.id]; setEditedTexts(n) }
                            setEditingId(null)
                          }}
                          style={{ fontSize: fontCqw, fontFamily: 'Helvetica, Arial, sans-serif', border: '1.5px solid #6366f1', background: 'rgba(255,255,255,0.97)', padding: 0, outline: 'none', borderRadius: 2, lineHeight: 1, width: '100%', minWidth: 60 }}
                        />
                      </div>
                    )

                    return (
                      <div key={item.id}
                        title={item.text}
                        onClick={e => { if (tool === 'text') { e.stopPropagation(); setEditingId(item.id); setPendingInput(null) } }}
                        onMouseEnter={e => { if (tool === 'text') (e.currentTarget as HTMLElement).style.outline = '1px dashed #6366f1' }}
                        onMouseLeave={e => { (e.currentTarget as HTMLElement).style.outline = isEdited ? '1px solid #6366f1' : 'none' }}
                        style={{ position: 'absolute', left: xPct, top: yPct, width: wPct, height: hPct, cursor: tool === 'text' ? 'text' : 'default', pointerEvents: tool === 'text' ? 'auto' : 'none', outline: isEdited ? '1px solid #6366f1' : 'none', background: isEdited ? 'rgba(99,102,241,0.08)' : 'transparent', boxSizing: 'border-box', zIndex: 5 }}
                      />
                    )
                  })}

                  {/* Click-to-add new text in blank area */}
                  {pendingInput && (
                    <div style={{ position: 'absolute', left: `${(pendingInput as any).xFrac*100}%`, top: `${(pendingInput as any).yFrac*100}%`, zIndex: 10, pointerEvents: 'auto' }}>
                      <input autoFocus value={pendingText}
                        onChange={e => setPendingText(e.target.value)}
                        onKeyDown={e => { if (e.key === 'Enter') commitText(); if (e.key === 'Escape') setPendingInput(null) }}
                        onBlur={commitText}
                        style={{ fontSize: fontSize * 0.75, color, fontFamily: 'Helvetica, Arial, sans-serif', border: '1px dashed #6366f1', background: 'rgba(255,255,255,0.9)', padding: '1px 4px', outline: 'none', minWidth: 80, borderRadius: 3 }}
                        placeholder="Type text…"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Annotation list */}
            {annotations.length > 0 && (
              <div className="mt-3 border border-gray-100 rounded-lg overflow-hidden">
                <div className="bg-gray-50 px-3 py-1.5 flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">Annotations ({annotations.length})</span>
                  <button onClick={() => setAnnotations([])} className="flex items-center gap-1 text-[11px] text-gray-400 hover:text-red-500"><Eraser size={11}/>Clear all</button>
                </div>
                <div className="divide-y divide-gray-50 max-h-36 overflow-y-auto">
                  {annotations.map(ann => (
                    <div key={ann.id} className="flex items-center justify-between px-3 py-1.5 text-xs">
                      <span className="text-gray-500">Pg {ann.page + 1} · {ann.type === 'text' ? `"${ann.text}"` : ann.type}</span>
                      <button onClick={() => removeAnnotation(ann.id)} className="text-gray-300 hover:text-red-500"><X size={12}/></button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <div className="text-xs text-gray-400 flex items-start gap-1.5">
        <AlertTriangle size={12} className="flex-shrink-0 mt-0.5"/>
        <span>
          Text tool: click existing PDF text to edit in place, or click blank area to add new text.
          Highlight/Whiteout: click-drag to select area. Press Enter to confirm, Escape to cancel.
        </span>
      </div>
    </div>
  )
}

interface YardContainer { id: string; veh_no: string; container_no: string; cusdec_no: string; cdn: string; shipper: string; time_in: string; duration: string; status: string; updated_at: string }

function TricoYardPanel() {
  const [items, setItems] = useState<YardContainer[]>([])
  const [loading, setLoading] = useState(false)
  const [syncing, setSyncing] = useState(false)
  const [statusMsg, setStatusMsg] = useState('')
  const [search, setSearch] = useState('')
  const searchRef = useRef(search)
  
  useEffect(() => { searchRef.current = search }, [search])

  async function load(silent = false) {
    if (!silent) setLoading(true)
    try {
      const res = await fetch(`/api/trico-yard-data?search=${searchRef.current}`, { headers: await authHeader() })
      if (res.ok) {
        const d = await res.json()
        setItems(d.items || [])
      }
    } finally { if (!silent) setLoading(false) }
  }

  useEffect(() => {
    load()
    const t = setInterval(() => load(true), 15000) // Auto refresh every 15s
    return () => clearInterval(t)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  async function triggerNow() {
    setSyncing(true); setStatusMsg('')
    try {
      const res = await fetch('/api/trico-yard-sync', { method: 'POST', headers: await authHeader() })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Failed to sync')
      setStatusMsg(`✓ Synced — ${d.message || 'Updated successfully'}`)
      load()
    } catch (e: any) {
      setStatusMsg(`✗ ${e.message}`)
    } finally {
      setSyncing(false)
    }
  }

  return (
    <div className="card max-w-5xl">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <h2 className="font-semibold text-gray-900 text-sm">Trico Containers in Yard</h2>
        <button onClick={triggerNow} disabled={syncing} className="btn-secondary flex items-center gap-2 text-xs">
          {syncing ? <Loader size={13} className="animate-spin"/> : <Zap size={13}/>}Sync Now
        </button>
      </div>
      
      {/* මෙය ඔබගේ පවතින SchedulerControl එක භාවිතා කරයි */}
      <div className="mb-3"><SchedulerControl panel="trico_yard" label="Sync Yard"/></div>
      
      {statusMsg && <p className={`text-xs mb-3 font-medium ${statusMsg.startsWith('✓') ? 'text-green-600' : 'text-red-600'}`}>{statusMsg}</p>}
      
      <div className="flex items-center gap-2 mb-3">
        <input value={search} onChange={e => { setSearch(e.target.value); load(); }} placeholder="Search container or shipper..." className="input max-w-sm"/>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><Loader size={18} className="animate-spin text-gray-400"/></div>
      ) : items.length === 0 ? (
        <p className="text-xs text-gray-400 text-center py-6">No data yet — click Sync Now</p>
      ) : (
        <div className="overflow-x-auto max-h-[32rem] overflow-y-auto rounded-lg border border-gray-100">
          <table className="w-full text-xs text-left">
            <thead className="bg-gray-50 sticky top-0 shadow-sm">
              <tr>
                <th className="px-3 py-2 font-medium text-gray-500">Veh. No</th>
                <th className="px-3 py-2 font-medium text-gray-500">Container</th>
                <th className="px-3 py-2 font-medium text-gray-500">CUSDEC</th>
                <th className="px-3 py-2 font-medium text-gray-500">CDN</th>
                <th className="px-3 py-2 font-medium text-gray-500">Shipper</th>
                <th className="px-3 py-2 font-medium text-gray-500">Time In</th>
                <th className="px-3 py-2 font-medium text-gray-500">Duration</th>
                <th className="px-3 py-2 font-medium text-gray-500">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {items.map(r => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2 text-gray-600">{r.veh_no}</td>
                  <td className="px-3 py-2 font-bold text-gray-800">{r.container_no}</td>
                  <td className="px-3 py-2 text-blue-600 font-medium">{r.cusdec_no}</td>
                  <td className="px-3 py-2 text-gray-600">{r.cdn}</td>
                  <td className="px-3 py-2 text-gray-600 truncate max-w-[150px]">{r.shipper}</td>
                  <td className="px-3 py-2 text-gray-600">{r.time_in}</td>
                  <td className="px-3 py-2 text-gray-600">{r.duration}</td>
                  <td className="px-3 py-2">
                    {r.status && <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold text-white ${r.status === 'E' ? 'bg-blue-500' : 'bg-green-500'}`}>{r.status}</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export default function AutomationPage() {
  return <AutomationContent/>
}
AutomationPage.getLayout = (page: React.ReactElement) => <AdminLayout>{page}</AdminLayout>