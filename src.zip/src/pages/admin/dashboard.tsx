import { useEffect, useState } from 'react'
import AdminLayout, { usePermission } from '@/components/admin/AdminLayout'
import { authHeader } from '@/lib/supabase'
import EmailPdfModal, { type EmailAttachment } from '@/components/admin/EmailPdfModal'
import AutomationErrorsPanel from '@/components/admin/AutomationErrorsPanel'
import {
  Ship, FileText, Package, Clock, AlertCircle, ChevronDown, Bell, Eye, UserCheck,
  Download, Mail, Undo2, Loader, History, Search, CheckSquare, Square, Trash2, FileCheck,
  DollarSign, Check, Lock, Printer,
} from 'lucide-react'

// A stored Drive URL is the "view" link (drive.google.com/file/d/<id>/view)
// — opening that in a new tab lands on Drive's preview page, not an actual
// download. Rewriting to the uc?export=download form makes the browser
// download the file directly instead, matching what "Download" should do.
function toDriveDownloadUrl(url: string): string {
  const m = url.match(/\/d\/([a-zA-Z0-9_-]+)/)
  return m ? `https://drive.google.com/uc?export=download&id=${m[1]}` : url
}

interface PendingGroup<T> { count: number; items: T[] }
// Vessel Trigger detail attached to a CDN Pending/Boat Note Pending
// container — only present when that vessel+voyage was actually found in
// the Vessel Trigger schedule (see dashboard-summary.ts's triggerByKey).
interface VesselContainer { containerNo: string; vessel: string; voyage: string; trigger: { openingTime: string; closingTime: string; etb: string } | null }
interface Summary {
  pendingCusdecPassed: PendingGroup<{ id: string; file_name: string; reason: string; reason_note: string | null; created_at: string }>
  shipmentsPending: PendingGroup<{ id: string; reference: string | null; shipper: string; invoice_number: string; packing_number: string | null; new_invoice: string | null; new_packing: string | null; cap: string | null; invoice_drive_url: string | null; packing_drive_url: string | null; license_drive_url: string | null; created_at: string; locked_by?: string | null; locked_by_name?: string | null }>
  cdnPending: PendingGroup<{ cusdecId: string; number: string; exporter: string; cap: number; cdnCount: number; containers: VesselContainer[] }>
  boatNotePending: PendingGroup<{ cusdecId: string; number: string; exporter: string; cap: number | null; cdnCount: number; passedCount: number; containers: VesselContainer[]; hasBoatNote: boolean; hasPartyCopy: boolean; locked?: boolean; lockedByName?: string | null }>
  releasePending: PendingGroup<{ cusdecId: string; number: string; exporter: string }>
  closingPassed: PendingGroup<{ cdnId: string; containerNo: string; cusdecNumber: string; vessel: string; voyage: string; closingTime: string }>
}
const emptyGroup = { count: 0, items: [] }

// Small tag shown next to a document wherever it appears (Activity Log, My
// Picked Tasks, Processed History) when it came through Quick Upload's
// reason-tagged flow — "CUSDEC Passed" gets its own color since that's the
// one reason that feeds the Dashboard's Pending CUSDEC Passed count.
function ReasonBadge({ reason, note }: { reason?: string | null; note?: string | null }) {
  if (!reason) return null
  const isCusdec = reason === 'CUSDEC Passed'
  return (
    <span className={`inline-block text-[10px] px-1.5 py-0.5 rounded font-medium ${isCusdec ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'}`}>
      {reason === 'Other' && note ? note : reason}
    </span>
  )
}

function docTypeLabel(v: string) { return v.split('_').filter(Boolean).map(w => w[0].toUpperCase() + w.slice(1)).join(' ') }
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve((reader.result as string).split(',')[1])
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

// Shown under a CDN/Boat Note Pending row — one line per container, but
// only the ones whose vessel+voyage was actually matched in the Vessel
// Trigger schedule get their opening/closing/ETB shown. Containers with no
// match (or no vessel/voyage yet) are skipped entirely rather than shown
// with blank fields.
function VesselContainerList({ containers }: { containers: VesselContainer[] }) {
  const matched = containers.filter(c => c.trigger)
  if (!matched.length) return null
  return (
    <div className="mt-2 pt-2 border-t border-gray-50 space-y-1">
      {matched.map(c => (
        <p key={c.containerNo} className="text-gray-500">
          <span className="font-medium text-gray-700">{c.containerNo || '—'}</span> · {c.vessel}/{c.voyage} · Opening: {c.trigger!.openingTime || '—'} · Closing: {c.trigger!.closingTime || '—'} · ETB: {c.trigger!.etb || '—'}
        </p>
      ))}
    </div>
  )
}

// getLayout (see _app.tsx) keeps AdminLayout mounted across navigations
// instead of remounting the sidebar on every tab click.
export default function AdminDashboard() {
  return <DashboardContent/>
}
AdminDashboard.getLayout = (page: React.ReactElement) => <AdminLayout>{page}</AdminLayout>

function DashboardContent() {
  const [summary, setSummary] = useState<Summary>({
    pendingCusdecPassed: emptyGroup, shipmentsPending: emptyGroup, cdnPending: emptyGroup, boatNotePending: emptyGroup, releasePending: emptyGroup, closingPassed: emptyGroup,
  })
  const [expanded, setExpanded] = useState<string | null>(null)
  // Bumped whenever Incoming's Pick succeeds, so My Picked Tasks re-fetches
  // immediately instead of needing a page refresh to show the new task.
  const [pickRefreshKey, setPickRefreshKey] = useState(0)
  const [currentUserId, setCurrentUserId] = useState('')
  const [finalDocsCount, setFinalDocsCount] = useState(0)
  const [notCompleteCount, setNotCompleteCount] = useState(0)
  const [notPaymentCount, setNotPaymentCount] = useState(0)
  const [autoErrorCount, setAutoErrorCount] = useState(0)
  const [pickingShipmentId, setPickingShipmentId] = useState<string | null>(null)
  const [shipmentPickError, setShipmentPickError] = useState('')

  // Boat Note Pending > Pick — select a batch of pending CUSDECs, merge
  // their Boat Note / Party's Copy / CDN PDFs (whichever categories are
  // ticked) into one file each, and send them through the normal
  // notify/pick flow (document-uploads, is_saved_to_db:false so it's
  // cleaned up from Drive once whoever picks it does Mail/Download).
  const [selectedPendingIds, setSelectedPendingIds] = useState<string[]>([])
  const [pickModalOpen, setPickModalOpen] = useState(false)
  const [pickIncludeBoat, setPickIncludeBoat] = useState(true)
  const [pickIncludeParty, setPickIncludeParty] = useState(true)
  const [pickIncludeCdn, setPickIncludeCdn] = useState(true)
  const [pickBusy, setPickBusy] = useState(false)
  const [pickError, setPickError] = useState('')
  const [pickDone, setPickDone] = useState('')

  function togglePendingSelected(id: string) {
    setSelectedPendingIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])
  }

  async function confirmPick() {
    if (!selectedPendingIds.length) return
    setPickBusy(true); setPickError(''); setPickDone('')
    try {
      const h = await authHeader()
      const mr = await fetch('/api/merge-pending-docs', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
        body: JSON.stringify({ cusdec_ids: selectedPendingIds, includeBoat: pickIncludeBoat, includeParty: pickIncludeParty, includeCdn: pickIncludeCdn }),
      })
      const md = await mr.json()
      if (!mr.ok) throw new Error(md.error || 'Merge failed')

      for (const f of md.files as { fileName: string; base64: string; docType: string }[]) {
        const dr = await fetch('/api/upload-to-drive', {
          method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
          body: JSON.stringify({ base64: f.base64, fileName: f.fileName, mimeType: 'application/pdf', docType: f.docType }),
        })
        const dd = await dr.json()
        if (!dr.ok || !dd.driveLink) throw new Error(dd.error || 'Drive upload failed')
        await fetch('/api/document-uploads', {
          method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
          body: JSON.stringify({
            file_name: f.fileName, drive_url: dd.driveLink, doc_type: f.docType,
            is_saved_to_db: false, notify: true, reason: 'Boat Note Passed',
            lock_cusdec_ids: selectedPendingIds,
          }),
        })
      }
      setPickDone(`✓ ${md.files.length} merged file(s) sent — pick them up from My Tasks`)
      setSelectedPendingIds([])
      setPickModalOpen(false)
    } catch (e: any) {
      setPickError(e.message)
    } finally {
      setPickBusy(false)
    }
  }

  async function load(silent = false) {
    const res = await fetch('/api/dashboard-summary', { headers: await authHeader() })
    const d = await res.json()
    if (res.ok) {
      setSummary({
        pendingCusdecPassed: d.pendingCusdecPassed || emptyGroup,
        shipmentsPending: d.shipmentsPending || emptyGroup,
        cdnPending: d.cdnPending || emptyGroup,
        boatNotePending: d.boatNotePending || emptyGroup,
        releasePending: d.releasePending || emptyGroup,
        closingPassed: d.closingPassed || emptyGroup,
      })
    }
  }

  useEffect(() => {
    load()
    // Live — the stat cards and their expanded lists stay current without a
    // page refresh, same polling convention as Incoming/My Picked Tasks below.
    const t = setInterval(() => load(true), 15000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    import('@/lib/supabase').then(({ supabase }) =>
      supabase.auth.getUser().then(({ data }) => setCurrentUserId(data.user?.id || ''))
    )
  }, [])

  async function pickShipment(id: string) {
    setPickingShipmentId(id); setShipmentPickError('')
    try {
      const res = await fetch('/api/pick-shipment', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ shipment_id: id }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      await load(true)
    } catch (e: any) { setShipmentPickError(e.message) }
    finally { setPickingShipmentId(null) }
  }

  async function resolveShipment(id: string) {
    setPickingShipmentId(id); setShipmentPickError('')
    try {
      const res = await fetch('/api/release-shipment', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ shipment_id: id }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      await load(true)
    } catch (e: any) { setShipmentPickError(e.message) }
    finally { setPickingShipmentId(null) }
  }

  const { has } = usePermission()

  const stats = [
    { key: 'section:dashboard.cusdec-pending',   id: 'shipments',label: 'Shipments Pending (no CUSDEC yet)', value: summary.shipmentsPending.count, icon: FileText,    color: '#f59e0b' },
    { key: 'section:dashboard.total-shipments',  id: 'pendingCusdec', label: 'Pending CUSDEC Passed',  value: summary.pendingCusdecPassed.count, icon: Ship,        color: '#1B3A5C' },
    { key: 'section:dashboard.cdn-pending',      id: 'cdn',      label: 'CDN Pending (CAP not complete)',    value: summary.cdnPending.count,       icon: Clock,       color: '#8b5cf6' },
    { key: 'section:dashboard.boatnote-pending', id: 'boatnote', label: 'Boat Note Pending',       value: summary.boatNotePending.count,    icon: Package,     color: '#3b82f6' },
    { key: 'section:dashboard.release-pending',  id: 'release',  label: 'Export Release Pending',  value: summary.releasePending.count,     icon: AlertCircle, color: '#ef4444' },
    { key: 'section:dashboard.closing-passed',   id: 'closingPassed', label: 'Closing Time Passed', value: summary.closingPassed.count,  icon: AlertCircle, color: '#dc2626' },
    { key: 'section:dashboard.final-documents',  id: 'finalDocs', label: 'Pending Final Document', value: finalDocsCount, icon: FileCheck, color: '#22A87A' },
    { key: 'section:dashboard.not-complete-shipment', id: 'notComplete', label: 'Not Complete Shipment', value: notCompleteCount, icon: AlertCircle, color: '#f97316' },
    { key: 'section:dashboard.not-payment-complete',  id: 'notPayment',  label: 'Not Payment Complete Shipment', value: notPaymentCount, icon: DollarSign, color: '#eab308' },
    { key: 'section:dashboard.automation-errors', id: 'autoErrors', label: 'Automate Errors', value: autoErrorCount, icon: AlertCircle, color: '#b91c1c' },
  ].filter(s => has(s.key))

  return (
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Export Management Overview</p>
        </div>

        {stats.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-4">
            {stats.map(({ id, label, value, icon: Icon, color }) => (
              <button key={id} onClick={() => id !== 'total' && setExpanded(x => x === id ? null : id)}
                className={`card text-left ${id !== 'total' ? 'cursor-pointer hover:shadow-md transition-shadow' : ''}`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: color + '20' }}>
                    <Icon size={18} style={{ color }}/>
                  </div>
                  {id !== 'total' && <ChevronDown size={14} className={`text-gray-300 transition-transform ${expanded === id ? 'rotate-180' : ''}`}/>}
                </div>
                <div className="text-2xl font-bold text-gray-900">{value}</div>
                <div className="text-xs text-gray-500 mt-1">{label}</div>
              </button>
            ))}
          </div>
        )}

        {expanded === 'pendingCusdec' && (
          <div className="card mb-4">
            <h2 className="font-semibold text-gray-900 mb-3 text-sm">Reason-tagged uploads awaiting Mail/Download (Quick Upload)</h2>
            <p className="text-xs text-gray-400 mb-3">These are temporary Drive-only uploads (Upload Docs → Quick Upload), not saved to any structured table. Whoever picks one and does Mail or Download removes it from this count.</p>
            {summary.pendingCusdecPassed.items.length === 0 ? (
              <p className="text-xs text-gray-400 py-4 text-center">None pending</p>
            ) : (
              <div className="space-y-1.5 max-h-96 overflow-y-auto">
                {summary.pendingCusdecPassed.items.map(r => (
                  <div key={r.id} className="flex items-center justify-between text-xs border border-gray-100 rounded-lg p-2.5">
                    <div>
                      <p className="font-medium text-gray-800">{r.file_name}</p>
                      <p className="text-gray-400">{new Date(r.created_at).toLocaleString('en-GB')}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {expanded === 'shipments' && (
          <div className="card mb-4">
            <h2 className="font-semibold text-gray-900 mb-3 text-sm">Shipments opened with no CUSDEC uploaded/matched yet</h2>
            <p className="text-xs text-gray-400 mb-3">Pick a shipment to work on it exclusively — it disappears from everyone else's list until you Resolve it or its CUSDEC is saved (which clears it automatically).</p>
            {shipmentPickError && <p className="text-xs text-red-600 mb-3 flex items-center gap-1"><AlertCircle size={12}/>{shipmentPickError}</p>}
            {summary.shipmentsPending.items.length === 0 ? (
              <p className="text-xs text-gray-400 py-4 text-center">None — every open Shipment has a matching CUSDEC</p>
            ) : (
              <div className="space-y-1.5 max-h-96 overflow-y-auto">
                {summary.shipmentsPending.items.map(s => {
                  const docs = [
                    { label: 'Invoice', url: s.invoice_drive_url },
                    { label: 'Packing', url: s.packing_drive_url },
                    { label: 'License', url: s.license_drive_url },
                  ].filter(d => d.url)
                  const pickedByMe = !!s.locked_by && s.locked_by === currentUserId
                  const busy = pickingShipmentId === s.id
                  return (
                    <div key={s.id} className={`text-xs border rounded-lg p-2.5 ${pickedByMe ? 'border-green-200 bg-green-50' : 'border-gray-100'}`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-gray-800">{s.shipper} · Inv: {s.invoice_number}</p>
                          <p className="text-gray-400">Ref: <b className="text-gray-600">{s.reference || '—'}</b> · Packing: {s.packing_number || '—'}</p>
                          {(s.new_invoice || s.new_packing || s.cap) && (
                            <p className="text-[11px] text-blue-600 mt-0.5">
                              {s.new_invoice && `New Inv: ${s.new_invoice}`}{s.new_invoice && s.new_packing ? ' · ' : ''}
                              {s.new_packing && `New Packing: ${s.new_packing}`}{(s.new_invoice || s.new_packing) && s.cap ? ' · ' : ''}
                              {s.cap && `CAP: ${s.cap}`}
                            </p>
                          )}
                          {pickedByMe && <p className="text-[11px] text-green-600 mt-0.5 flex items-center gap-1"><UserCheck size={11}/>Picked by you — upload the CUSDEC to complete it</p>}
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          {pickedByMe ? (
                            <button onClick={() => resolveShipment(s.id)} disabled={busy}
                              className="flex items-center gap-1 text-[11px] px-2 py-1 rounded border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-50">
                              {busy ? <Loader size={11} className="animate-spin"/> : <Undo2 size={11}/>} Resolve
                            </button>
                          ) : (
                            <button onClick={() => pickShipment(s.id)} disabled={busy}
                              className="flex items-center gap-1 text-[11px] px-2 py-1 rounded text-white disabled:opacity-50" style={{ background: '#22A87A' }}>
                              {busy ? <Loader size={11} className="animate-spin"/> : <UserCheck size={11}/>} Pick
                            </button>
                          )}
                          <a href={`/admin/shipment-overview?invoiceNumber=${encodeURIComponent(s.invoice_number)}`} className="text-blue-600 hover:underline">View →</a>
                        </div>
                      </div>
                      {docs.length > 0 && (
                        <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                          {docs.map(d => (
                            <a key={d.label} href={d.url!} target="_blank" rel="noreferrer" className="text-blue-500 underline text-[11px]">{d.label} PDF</a>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {expanded === 'cdn' && (
          <div className="card mb-4">
            <h2 className="font-semibold text-gray-900 mb-3 text-sm">CUSDECs whose CAP isn't filled yet</h2>
            {summary.cdnPending.items.length === 0 ? (
              <p className="text-xs text-gray-400 py-4 text-center">None — every CUSDEC's CAP is complete</p>
            ) : (
              <div className="space-y-1.5 max-h-96 overflow-y-auto">
                {summary.cdnPending.items.map(c => (
                  <div key={c.cusdecId} className="text-xs border border-gray-100 rounded-lg p-2.5">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-800">E {c.number}</p>
                        <p className="text-gray-400 truncate max-w-[240px]">{c.exporter}</p>
                      </div>
                      <span className="font-medium text-purple-700">{c.cdnCount}/{c.cap} CDN <span className="text-red-500">({c.cap - c.cdnCount} remaining)</span></span>
                      <a href={`/admin/shipment-overview?number=${encodeURIComponent(c.number)}`} className="text-blue-600 hover:underline flex-shrink-0">View →</a>
                    </div>
                    <VesselContainerList containers={c.containers}/>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {expanded === 'boatnote' && (
          <div className="card mb-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-gray-900 text-sm">CAP complete, still waiting on Boat Note</h2>
              {selectedPendingIds.length > 0 && (
                <button onClick={() => { setPickModalOpen(true); setPickError('') }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white" style={{ background: '#3b82f6' }}>
                  <CheckSquare size={13}/>Pick ({selectedPendingIds.length})
                </button>
              )}
            </div>
            {pickDone && <p className="text-xs text-green-600 mb-3">{pickDone}</p>}
            {summary.boatNotePending.items.length === 0 ? (
              <p className="text-xs text-gray-400 py-4 text-center">None — every CAP-complete CUSDEC has passed Boat Note</p>
            ) : (
              <div className="space-y-1.5 max-h-96 overflow-y-auto">
                {summary.boatNotePending.items.map(c => (
                  <div key={c.cusdecId} className={`text-xs border rounded-lg p-2.5 ${c.locked ? 'border-amber-200 bg-amber-50/40' : 'border-gray-100'}`}>
                    <div className="flex items-center justify-between gap-2">
                      {c.locked ? (
                        <span title={`Picked by ${c.lockedByName || '—'} — awaiting Mail/Download`} className="flex-shrink-0">
                          <Lock size={14} className="text-amber-500"/>
                        </span>
                      ) : (
                        <button onClick={() => togglePendingSelected(c.cusdecId)} className="flex-shrink-0">
                          {selectedPendingIds.includes(c.cusdecId) ? <CheckSquare size={15} className="text-blue-600"/> : <Square size={15} className="text-gray-300"/>}
                        </button>
                      )}
                      <div className="flex-1">
                        <div className="flex items-center gap-1.5">
                          <p className="font-medium text-gray-800">E {c.number}</p>
                          {c.hasBoatNote && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-700">B</span>}
                          {c.hasPartyCopy && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-700">P</span>}
                          {c.locked && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-700">Picked by {c.lockedByName || '—'}</span>}
                        </div>
                        <p className="text-gray-400 truncate max-w-[240px]">{c.exporter}</p>
                      </div>
                      <span className="font-medium text-blue-700 flex-shrink-0">{c.passedCount}/{c.cdnCount} passed</span>
                      <a href={`/admin/shipment-overview?number=${encodeURIComponent(c.number)}`} className="text-blue-600 hover:underline flex-shrink-0">View →</a>
                    </div>
                    <VesselContainerList containers={c.containers}/>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {pickModalOpen && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[70] p-4">
            <div className="bg-white rounded-2xl w-full max-w-sm">
              <div className="p-5 border-b">
                <h2 className="font-bold text-gray-900 text-sm">Pick {selectedPendingIds.length} CUSDEC(s)</h2>
              </div>
              <div className="p-5 space-y-2">
                <label className="flex items-center gap-3 p-2.5 rounded-lg border border-gray-100 cursor-pointer hover:bg-gray-50">
                  <input type="checkbox" checked={pickIncludeBoat} onChange={e => setPickIncludeBoat(e.target.checked)} className="w-4 h-4"/>
                  <span className="text-sm text-gray-800">Boat Note</span>
                </label>
                <label className="flex items-center gap-3 p-2.5 rounded-lg border border-gray-100 cursor-pointer hover:bg-gray-50">
                  <input type="checkbox" checked={pickIncludeParty} onChange={e => setPickIncludeParty(e.target.checked)} className="w-4 h-4"/>
                  <span className="text-sm text-gray-800">Party's Copy</span>
                </label>
                <label className="flex items-center gap-3 p-2.5 rounded-lg border border-gray-100 cursor-pointer hover:bg-gray-50">
                  <input type="checkbox" checked={pickIncludeCdn} onChange={e => setPickIncludeCdn(e.target.checked)} className="w-4 h-4"/>
                  <span className="text-sm text-gray-800">CDNs</span>
                </label>
                <p className="text-[11px] text-gray-400">Merges each ticked category across all selected CUSDECs into one PDF, uploads it, and sends it to My Tasks (reason: Boat Note Passed).</p>
                {pickError && <p className="text-xs text-red-600">{pickError}</p>}
              </div>
              <div className="flex gap-3 p-5 border-t">
                <button onClick={() => setPickModalOpen(false)} disabled={pickBusy} className="btn-secondary flex-1 disabled:opacity-50">Cancel</button>
                <button onClick={confirmPick} disabled={pickBusy || (!pickIncludeBoat && !pickIncludeParty && !pickIncludeCdn)}
                  className="btn-primary flex-1 flex items-center justify-center gap-2 disabled:opacity-40">
                  {pickBusy ? <Loader size={14} className="animate-spin"/> : <CheckSquare size={14}/>}Merge &amp; Send
                </button>
              </div>
            </div>
          </div>
        )}

        {expanded === 'release' && (
          <div className="card mb-4">
            <h2 className="font-semibold text-gray-900 mb-3 text-sm">Boat Note passed (blue), waiting on Export Release</h2>
            {summary.releasePending.items.length === 0 ? (
              <p className="text-xs text-gray-400 py-4 text-center">None — every Boat Note-passed CUSDEC has been released</p>
            ) : (
              <div className="space-y-1.5 max-h-96 overflow-y-auto">
                {summary.releasePending.items.map(c => (
                  <div key={c.cusdecId} className="flex items-center justify-between text-xs border border-gray-100 rounded-lg p-2.5">
                    <div>
                      <p className="font-medium text-gray-800">E {c.number}</p>
                      <p className="text-gray-400 truncate max-w-[240px]">{c.exporter}</p>
                    </div>
                    <a href={`/admin/shipment-overview?number=${encodeURIComponent(c.number)}`} className="text-blue-600 hover:underline flex-shrink-0">View →</a>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {expanded === 'closingPassed' && (
          <div className="card mb-4">
            <h2 className="font-semibold text-gray-900 mb-3 text-sm flex items-center gap-2"><AlertCircle size={15} className="text-red-600"/>Vessel closing time has passed — not yet Boat Note/Export Release passed</h2>
            <p className="text-xs text-gray-400 mb-3">Checked against the Vessel Triggers schedule (Automation tab) each time it syncs — matched by Vessel + Voyage together, since the same voyage number can appear against more than one vessel.</p>
            {summary.closingPassed.items.length === 0 ? (
              <p className="text-xs text-gray-400 py-4 text-center">None — no pending container's closing time has passed</p>
            ) : (
              <div className="space-y-1.5 max-h-96 overflow-y-auto">
                {summary.closingPassed.items.map(c => (
                  <div key={c.cdnId} className="flex items-center justify-between text-xs border border-red-100 bg-red-50 rounded-lg p-2.5">
                    <div>
                      <p className="font-medium text-gray-800">{c.containerNo || '—'} <span className="text-gray-400 font-normal">· E {c.cusdecNumber}</span></p>
                      <p className="text-gray-500">{c.vessel} / {c.voyage} · Closing: {c.closingTime}</p>
                    </div>
                    <a href={`/admin/shipment-overview?containerNo=${encodeURIComponent(c.containerNo || '')}`} className="text-blue-600 hover:underline flex-shrink-0">View →</a>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {expanded === 'finalDocs' && (
          <div className="mb-4">
            <PendingFinalDocumentsPanel currentUserId={currentUserId} onCountChange={setFinalDocsCount}/>
          </div>
        )}
        {/* Keeps the stat card's count fresh even while collapsed — this
            component polls internally regardless of whether it's rendered
            expanded, so mount it invisibly when collapsed just for the count. */}
        {expanded !== 'finalDocs' && has('section:dashboard.final-documents') && (
          <div className="hidden"><PendingFinalDocumentsPanel currentUserId={currentUserId} onCountChange={setFinalDocsCount}/></div>
        )}

        {expanded === 'notComplete' && (
          <div className="mb-4">
            <ShipmentCompletionPanel mode="shipment" onCountChange={setNotCompleteCount}/>
          </div>
        )}
        {expanded !== 'notComplete' && has('section:dashboard.not-complete-shipment') && (
          <div className="hidden"><ShipmentCompletionPanel mode="shipment" onCountChange={setNotCompleteCount}/></div>
        )}

        {expanded === 'notPayment' && (
          <div className="mb-4">
            <ShipmentCompletionPanel mode="payment" onCountChange={setNotPaymentCount}/>
          </div>
        )}
        {expanded !== 'notPayment' && has('section:dashboard.not-payment-complete') && (
          <div className="hidden"><ShipmentCompletionPanel mode="payment" onCountChange={setNotPaymentCount}/></div>
        )}

        {expanded === 'autoErrors' && (
          <div className="mb-4">
            <AutomationErrorsPanel onCountChange={setAutoErrorCount}/>
          </div>
        )}
        {expanded !== 'autoErrors' && has('section:dashboard.automation-errors') && (
          <div className="hidden"><AutomationErrorsPanel onCountChange={setAutoErrorCount}/></div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-2">
          {has('section:dashboard.incoming') && <IncomingPanel onPicked={() => setPickRefreshKey(k => k + 1)}/>}
          {has('section:dashboard.my-picked-tasks') && <MyPickedTasksPanel refreshKey={pickRefreshKey}/>}
        </div>

        {has('section:dashboard.pick-history') && <PickHistoryPanel/>}
      </div>
  )
}

// Activity Log reason filter — same reasons the Send panel offers
// (SendModal's REASON_OPTIONS), plus "All".
const ACTIVITY_REASON_FILTERS = ['All', 'Boat Note Passed', 'CUSDEC Passed', 'Container Moved', 'Final Document', 'Other']

// Temporary merged files (CUSDEC set / Boat Note set / CDN set) made by
// /api/merge-picked-boat-notes when Boat Note Passed (B...) documents are
// mailed or downloaded from My Picked Tasks.
type TempMergedFile = { fileName: string; driveLink: string; driveId: string; docType: string }
const TEMP_BACKUP_EMAIL = 'bathiyapradeep7788@gmail.com'
const TEMP_MERGE_SUBJECT = 'Boat Note Passed'

// ── Incoming (Notify) — every signed-in user sees every still-active
// notification; Pick locks it to just them (see pick-task.ts's atomic claim).
// Multiple can be ticked and picked together in one go.
function IncomingPanel({ onPicked }: { onPicked: () => void }) {
  const { isAdmin } = usePermission()
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [pickingId, setPickingId] = useState<string | null>(null)
  const [pickingAll, setPickingAll] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [viewing, setViewing] = useState<any | null>(null)
  const [selected, setSelected] = useState<Record<string, boolean>>({})
  const [reasonFilter, setReasonFilter] = useState('All')

  async function load(silent = false) {
    if (!silent) setLoading(true)
    try {
      const res = await fetch('/api/dashboard-notifications', { headers: await authHeader() })
      const d = await res.json()
      if (res.ok) setItems(d.notifications || [])
    } finally { if (!silent) setLoading(false) }
  }
  // Live updates: a new upload shows up here within a few seconds without a
  // page refresh — polling rather than a Realtime subscription since it
  // needs zero Supabase publication setup and the spec explicitly allows
  // either. Silent (no loading spinner) so it doesn't flicker every tick.
  useEffect(() => {
    load()
    const t = setInterval(() => load(true), 6000)
    return () => clearInterval(t)
  }, [])

  function toggle(id: string) { setSelected(prev => ({ ...prev, [id]: !prev[id] })) }
  // Everything below (Select all, Pick Selected, Delete Selected) works on
  // the FILTERED list only, so picking "Boat Note Passed" + Select all can
  // never pick a CUSDEC Passed item that isn't on screen.
  const visibleItems = reasonFilter === 'All' ? items : items.filter(n => (n.document_uploads?.reason || '') === reasonFilter)
  const selectedIds = visibleItems.filter(n => selected[n.id]).map(n => n.id)
  const allSelected = visibleItems.length > 0 && selectedIds.length === visibleItems.length
  function toggleAll() { setSelected(allSelected ? {} : Object.fromEntries(visibleItems.map(n => [n.id, true]))) }
  function reasonCount(r: string) { return r === 'All' ? items.length : items.filter(n => (n.document_uploads?.reason || '') === r).length }

  async function pickOne(n: any): Promise<boolean> {
    try {
      const res = await fetch('/api/pick-task', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ notification_id: n.id, document_id: n.document_uploads?.id }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      return true
    } catch (e: any) {
      return false
    }
  }

  async function pick(n: any) {
    setPickingId(n.id)
    const ok = await pickOne(n)
    if (ok) { setItems(prev => prev.filter(x => x.id !== n.id)); onPicked() }
    else { alert('Someone else already picked this'); load() }
    setPickingId(null)
  }

  async function pickSelected() {
    setPickingAll(true)
    const toPick = visibleItems.filter(n => selected[n.id])
    let anyOk = false
    for (const n of toPick) {
      const ok = await pickOne(n)
      if (ok) { anyOk = true; setItems(prev => prev.filter(x => x.id !== n.id)) }
    }
    setSelected({})
    setPickingAll(false)
    if (anyOk) onPicked()
    load()
  }

  function look(n: any) {
    setViewing(n)
    if (n.document_uploads?.id) {
      authHeader().then(h => fetch('/api/log-document-action', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
        body: JSON.stringify({ document_id: n.document_uploads.id, action: 'look' }),
      })).catch(() => {})
    }
  }

  // Admin-only — dismisses from this log (is_active=false server-side), the
  // document/upload itself is never touched, same spirit as Processed
  // History's "clears the log, not the file" delete.
  async function deleteSelected() {
    const ids = selectedIds
    if (!ids.length || !confirm(`Remove ${ids.length} entr${ids.length === 1 ? 'y' : 'ies'} from the Activity Log? The uploaded files themselves are not affected.`)) return
    setDeleting(true)
    try {
      const res = await fetch('/api/dashboard-notifications', {
        method: 'DELETE', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ ids }),
      })
      if (res.ok) { setItems(prev => prev.filter(x => !ids.includes(x.id))); setSelected({}) }
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-semibold text-gray-900 text-sm flex items-center gap-2"><Bell size={16} className="text-amber-500"/>Activity Log</h2>
        {selectedIds.length > 0 && (
          <div className="flex items-center gap-1.5">
            <button onClick={pickSelected} disabled={pickingAll}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs text-white disabled:opacity-50" style={{ background: '#22A87A' }}>
              {pickingAll ? <Loader size={12} className="animate-spin"/> : <UserCheck size={12}/>} Pick Selected ({selectedIds.length})
            </button>
            {isAdmin && (
              <button onClick={deleteSelected} disabled={deleting}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs text-white disabled:opacity-50" style={{ background: '#ef4444' }}>
                {deleting ? <Loader size={12} className="animate-spin"/> : <Trash2 size={12}/>} Delete Selected ({selectedIds.length})
              </button>
            )}
          </div>
        )}
      </div>
      <div className="flex items-center gap-2 mb-2">
        <select value={reasonFilter} onChange={e => { setReasonFilter(e.target.value); setSelected({}) }}
          className="border border-gray-200 rounded-md px-2 py-1 text-xs text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-green-400">
          {ACTIVITY_REASON_FILTERS.map(r => <option key={r} value={r}>{r === 'All' ? 'All reasons' : r} ({reasonCount(r)})</option>)}
        </select>
      </div>
      {loading ? (
        <div className="flex justify-center py-8"><Loader size={18} className="animate-spin text-gray-400"/></div>
      ) : visibleItems.length === 0 ? (
        <p className="text-xs text-gray-400 text-center py-6">{items.length === 0 ? 'Nothing waiting' : `Nothing waiting for "${reasonFilter}"`}</p>
      ) : (
        <div className="space-y-1.5 max-h-80 overflow-y-auto">
          <button onClick={toggleAll} className="flex items-center gap-2 text-xs text-gray-400 hover:text-gray-600 px-0.5 pb-1">
            {allSelected ? <CheckSquare size={14} className="text-green-600"/> : <Square size={14}/>} Select all
          </button>
          {visibleItems.map(n => (
            <div key={n.id} className="flex items-center justify-between text-xs border border-gray-100 rounded-lg p-2.5">
              <div className="flex items-center gap-2 min-w-0">
                <button onClick={() => toggle(n.id)} className="flex-shrink-0 text-gray-300 hover:text-green-600">
                  {selected[n.id] ? <CheckSquare size={14} className="text-green-600"/> : <Square size={14}/>}
                </button>
                <div className="min-w-0">
                  <p className="font-medium text-gray-800 truncate flex items-center gap-1.5">
                    {n.document_uploads?.file_name}
                    <ReasonBadge reason={n.document_uploads?.reason} note={n.document_uploads?.reason_note}/>
                  </p>
                  <p className="text-gray-400">{n.uploaded_by_name || 'Someone'} uploaded this</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <button onClick={() => look(n)} className="flex items-center gap-1 px-2 py-1.5 rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50">
                  <Eye size={12}/> Look Only
                </button>
                <button onClick={() => pick(n)} disabled={pickingId === n.id}
                  className="flex items-center gap-1 px-2 py-1.5 rounded-md text-white disabled:opacity-50" style={{ background: '#22A87A' }}>
                  {pickingId === n.id ? <Loader size={12} className="animate-spin"/> : <UserCheck size={12}/>} Pick
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {viewing && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setViewing(null)}>
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-4 border-b">
              <p className="font-semibold text-sm truncate">{viewing.document_uploads?.file_name}</p>
              <button onClick={() => setViewing(null)} className="text-gray-400 hover:text-gray-700">✕</button>
            </div>
            <div className="flex-1 overflow-auto p-2 bg-gray-50">
              {viewing.document_uploads?.drive_url ? (
                <iframe src={viewing.document_uploads.drive_url.replace('/view', '/preview')} className="w-full h-[70vh] rounded-lg border-0"/>
              ) : (
                <p className="text-xs text-gray-400 text-center py-10">No file link available</p>
              )}
            </div>
            <p className="text-[10px] text-gray-400 px-4 py-2 border-t">View only — download and mail aren't available here.</p>
          </div>
        </div>
      )}
    </div>
  )
}

// ── My Picked Tasks — full access (download/mail) to whatever this user
// picked; Resolve/Return hands it back to Incoming for everyone else. Ticks
// let several be downloaded/mailed/returned together in one action.
function MyPickedTasksPanel({ refreshKey }: { refreshKey: number }) {
  const { isAdmin } = usePermission()
  const [tasks, setTasks] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [bulkBusy, setBulkBusy] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [emailAttachments, setEmailAttachments] = useState<EmailAttachment[] | null>(null)
  const [pendingMailActions, setPendingMailActions] = useState<{ taskIds: string[]; docIds: { id: string; ephemeral: boolean }[] } | null>(null)
  const [emailReason, setEmailReason] = useState<{ reason: string | null; note: string | null } | null>(null)
  const [selected, setSelected] = useState<Record<string, boolean>>({})
  // Boat Note Passed merge: true while the merged sets are being built, and
  // the temporary Drive files that go out with the current Mail popup.
  const [merging, setMerging] = useState(false)
  const [tempFiles, setTempFiles] = useState<TempMergedFile[] | null>(null)

  async function load(silent = false) {
    if (!silent) setLoading(true)
    try {
      const res = await fetch('/api/user-tasks', { headers: await authHeader() })
      const d = await res.json()
      if (res.ok) setTasks(d.tasks || [])
    } finally { if (!silent) setLoading(false) }
  }
  useEffect(() => {
    load()
    const t = setInterval(() => load(true), 8000)
    return () => clearInterval(t)
  }, [refreshKey])

  function toggle(id: string) { setSelected(prev => ({ ...prev, [id]: !prev[id] })) }
  const selectedTasks = tasks.filter(t => selected[t.id])
  const allSelected = tasks.length > 0 && selectedTasks.length === tasks.length
  function toggleAll() { setSelected(allSelected ? {} : Object.fromEntries(tasks.map(t => [t.id, true]))) }

  async function returnTask(taskId: string) {
    const res = await fetch('/api/user-tasks', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
      body: JSON.stringify({ task_id: taskId }),
    })
    const d = await res.json()
    if (!res.ok) throw new Error(d.error)
  }

  async function handleReturn(taskId: string) {
    setBusyId(taskId)
    try {
      await returnTask(taskId)
      setTasks(prev => prev.filter(t => t.id !== taskId))
    } catch (e: any) {
      alert(e.message)
    } finally {
      setBusyId(null)
    }
  }

  async function returnSelected() {
    setBulkBusy(true)
    for (const t of selectedTasks) {
      try { await returnTask(t.id) } catch { /* keep going through the rest */ }
    }
    setSelected({})
    setBulkBusy(false)
    load()
  }

  function logAction(documentId: string, action: 'mail' | 'download' | 'print') {
    authHeader().then(h => fetch('/api/log-document-action', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
      body: JSON.stringify({ document_id: documentId, action }),
    })).catch(() => {})
  }

  // Reason-tagged Quick Uploads are meant to be temporary: Mail or Download
  // is the last thing that happens to them, so confirming here both permits
  // the action AND deletes the document (Drive file + every trace of it) —
  // that delete is what takes it out of the Dashboard's Pending CUSDEC
  // Passed count. Declining the confirm blocks the mail/download entirely.
  // One confirm for the whole batch, not one popup per reason-tagged item —
  // if none of the given tasks have a reason, no prompt at all. A reasoned
  // upload that was ALSO Saved (is_saved_to_db) isn't temporary anymore — it
  // has a real structured-table row + Drive file like any normal document,
  // so it's treated exactly like one here (no delete-on-pick, no confirm).
  function isEphemeralReason(doc: any): boolean {
    return !!doc?.reason && !doc?.is_saved_to_db
  }
  function confirmReasonDeleteBatch(tasksToCheck: any[]): boolean {
    const reasoned = tasksToCheck.filter(t => isEphemeralReason(t.document_uploads))
    if (!reasoned.length) return true
    return confirm(`${reasoned.length} of the selected document${reasoned.length === 1 ? '' : 's'} will be permanently removed after this. Continue with Mail/Download?`)
  }
  function confirmReasonDelete(doc?: { reason?: string | null; is_saved_to_db?: boolean } | null): boolean {
    if (!isEphemeralReason(doc)) return true
    return confirm(`This document (reason: ${doc?.reason}) will be permanently removed after this. Continue with Mail/Download?`)
  }
  function deleteReasonDoc(documentId: string) {
    authHeader().then(h => fetch('/api/delete-reason-document', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
      body: JSON.stringify({ document_id: documentId }),
    })).catch(() => {})
  }

  // ── Boat Note Passed (B...) documents ────────────────────────────────
  // Mail/Download of these does NOT send the B PDF itself: the server finds
  // each one's CUSDEC/Party's Copy/CDNs in the database and builds up to
  // three merged temporary files for the whole selection (CUSDEC set, Boat
  // Note set, CDN set). Those are what gets mailed/downloaded.
  function isBoatNoteTask(t: any): boolean {
    const d = t?.document_uploads
    return !!d && d.reason === 'Boat Note Passed' && (d.doc_type === 'boat_note' || /^B\d/i.test(d.file_name || ''))
  }

  async function mergeBoatNoteTasks(boatTasks: any[]): Promise<TempMergedFile[] | null> {
    setMerging(true)
    try {
      const res = await fetch('/api/merge-picked-boat-notes', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ document_ids: boatTasks.map(t => t.document_uploads.id) }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Merge failed')
      if (Array.isArray(d.warnings) && d.warnings.length) alert('Note:\n- ' + d.warnings.join('\n- '))
      return d.files as TempMergedFile[]
    } catch (e: any) {
      alert(e.message)
      return null
    } finally {
      setMerging(false)
    }
  }

  // Uses the same /api/delete-temp-merge-file endpoint the Automation > Merge
  // PDF tab already uses for its temporary Drive copy (one call per file).
  function deleteTempFiles(files: TempMergedFile[]) {
    authHeader().then(h => Promise.all(files.map(f => fetch('/api/delete-temp-merge-file', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
      body: JSON.stringify({ drive_url: f.driveLink }),
    }).catch(() => {})))).catch(() => {})
  }

  // After Mail/Download: OK deletes the temporary merged files. Cancel first
  // emails them to the backup address (subject = the reason), and only
  // deletes them once that mail has actually gone out — if the mail fails
  // the files are kept so nothing is lost.
  async function cleanupTempFiles(files: TempMergedFile[]) {
    const ok = confirm(`Delete the ${files.length} temporary merged file${files.length === 1 ? '' : 's'}?\n\nOK = delete now.\nCancel = they are emailed to ${TEMP_BACKUP_EMAIL} first, then deleted.`)
    if (!ok) {
      try {
        const res = await fetch('/api/send-email', {
          method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
          body: JSON.stringify({
            to: TEMP_BACKUP_EMAIL, subject: TEMP_MERGE_SUBJECT, body: '',
            attachments: files.map(f => ({ filename: f.fileName, url: f.driveLink })), useDocsAccount: true,
          }),
        })
        const d = await res.json()
        if (!res.ok) throw new Error(d.error)
      } catch (e: any) {
        alert(`Could not email the temporary files to ${TEMP_BACKUP_EMAIL} (${e.message}). They were NOT deleted.`)
        return
      }
    }
    deleteTempFiles(files)
  }

  // A hidden iframe starts a download without being treated as a popup
  // (window.open after an await gets blocked by the browser).
  function downloadViaFrame(url: string) {
    const f = document.createElement('iframe')
    f.style.display = 'none'
    f.src = url
    document.body.appendChild(f)
    setTimeout(() => f.remove(), 60000)
  }

  // Mail or Download — whichever happens first — auto-resolves the task
  // server-side (log-document-action.ts), so it's removed from view here
  // right away instead of waiting for the next full reload.
  async function downloadTasks(list: any[]) {
    if (!confirmReasonDeleteBatch(list)) return
    const ids = new Set(list.map(t => t.id))
    const boat = list.filter(isBoatNoteTask)
    if (!boat.length) {
      // No browser event exists for "the save dialog was actually completed
      // vs cancelled" on a triggered download — rather than a confirm() the
      // user has to answer honestly every time, this removes the task on
      // click (matching Mail's "sent = done" feel) and leaves Processed
      // History's per-entry "Restore to Picked Tasks" (admin) as the correct
      // way back in if a download never actually finished.
      for (const t of list) {
        if (!t.document_uploads?.drive_url) continue
        window.open(toDriveDownloadUrl(t.document_uploads.drive_url), '_blank')
        logAction(t.document_uploads.id, 'download')
        if (isEphemeralReason(t.document_uploads)) deleteReasonDoc(t.document_uploads.id)
      }
      setTasks(prev => prev.filter(t => !ids.has(t.id)))
      setSelected({})
      return
    }

    const merged = await mergeBoatNoteTasks(boat)
    if (!merged) return   // error already shown — nothing downloaded, tasks stay
    const others = list.filter(t => !isBoatNoteTask(t) && t.document_uploads?.drive_url)
    for (const f of merged) { downloadViaFrame(toDriveDownloadUrl(f.driveLink)); await new Promise(r => setTimeout(r, 700)) }
    for (const t of others) { downloadViaFrame(toDriveDownloadUrl(t.document_uploads.drive_url)); await new Promise(r => setTimeout(r, 700)) }
    for (const t of list) {
      if (!t.document_uploads?.drive_url) continue
      logAction(t.document_uploads.id, 'download')
      if (isEphemeralReason(t.document_uploads)) deleteReasonDoc(t.document_uploads.id)
    }
    setTasks(prev => prev.filter(t => !ids.has(t.id)))
    setSelected({})
    // Give the downloads a moment to start before asking about the temp files.
    setTimeout(() => cleanupTempFiles(merged), 2500)
  }

  // Print — same "finishes the task" weight as Mail/Download (counts, logs,
  // removes it from this list, deletes a reason-tagged temp doc), but each
  // PDF opens in its OWN tab, straight in the browser's PDF viewer (its
  // toolbar has Print), instead of Drive's preview page:
  //   • a normal picked document          → its own tab
  //   • a B... Boat Note Passed document  → its sets open as separate tabs:
  //     CUSDEC Set (Party's Copy), Boat Note Set and CDN Set
  // Nothing is combined into one PDF here, so each PDF = one tab = one print job.
  //
  // Browsers only allow window.open inside the click itself (before any
  // await), so one blank "Preparing…" tab per expected PDF is opened first
  // and each is pointed at its PDF once ready, or closed if it failed.
  // Nothing is logged/removed until at least one PDF really opened; a total
  // failure leaves every task exactly where it was.
  function openPreparingTab(): Window | null {
    const w = window.open('', '_blank')
    if (w) {
      try { w.document.write('<title>Preparing PDF…</title><p style="font-family:sans-serif;padding:24px;color:#555">Preparing PDF for print…</p>') } catch { /* ignore */ }
    }
    return w
  }

  async function openPdfForPrint(driveUrl: string, win: Window | null): Promise<boolean> {
    try {
      const res = await fetch('/api/print-pdf-link', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ drive_urls: [driveUrl] }),
      })
      const d = await res.json()
      if (!res.ok || !d.url) throw new Error(d.error || 'Could not prepare the PDF for print')
      if (win && !win.closed) win.location.href = d.url
      else window.open(d.url, '_blank')
      return true
    } catch (e: any) {
      if (win && !win.closed) win.close()
      console.error('[print] could not open a PDF:', e?.message || e)
      return false
    }
  }

  async function printTasks(list: any[]) {
    if (!confirmReasonDeleteBatch(list)) return
    const boat = list.filter(isBoatNoteTask)
    const others = list.filter(t => !isBoatNoteTask(t) && t.document_uploads?.drive_url)
    // One tab per PDF that will open: picked Boat Note documents produce up to
    // 3 PDFs between them (CUSDEC Set, Boat Note Set, CDN Set — see
    // merge-picked-boat-notes), plus one per other document. Any tab that
    // turns out not to be needed is closed again below.
    const wins: (Window | null)[] = []
    for (let i = 0; i < (boat.length ? 3 : 0) + others.length; i++) wins.push(openPreparingTab())
    const closeAll = () => wins.forEach(w => { if (w && !w.closed) w.close() })
    if (wins.length > 1 && wins.some(w => !w)) alert('Your browser blocked some of the new tabs. Allow pop-ups for this site to print several PDFs at once.')

    const ids = new Set(list.map(t => t.id))
    let merged: TempMergedFile[] = []
    if (boat.length) {
      const m = await mergeBoatNoteTasks(boat)
      if (!m) { closeAll(); return }   // error already shown — nothing opened, tasks stay
      merged = m
    }
    const urls = [...merged.map(f => f.driveLink), ...others.map(t => t.document_uploads.drive_url)]
    if (!urls.length) { closeAll(); return }
    // Tabs that were opened but won't be needed (fewer merged files than Boat Notes).
    wins.slice(urls.length).forEach(w => { if (w && !w.closed) w.close() })

    const results = await Promise.all(urls.map((u, i) => openPdfForPrint(u, wins[i] ?? null)))
    const okCount = results.filter(Boolean).length
    if (okCount === 0) {
      alert('Could not prepare the PDF for print. Nothing was removed from your picked tasks.')
      if (merged.length) deleteTempFiles(merged)
      return
    }
    if (okCount < urls.length) alert(`${urls.length - okCount} of ${urls.length} PDFs could not be opened.`)
    for (const t of list) {
      if (!t.document_uploads?.drive_url) continue
      logAction(t.document_uploads.id, 'print')
      if (isEphemeralReason(t.document_uploads)) deleteReasonDoc(t.document_uploads.id)
    }
    setTasks(prev => prev.filter(t => !ids.has(t.id)))
    setSelected({})
    // The PDFs were already copied out of Drive by the server, so the temporary
    // merged Drive files are safe to clean up straight away.
    if (merged.length) setTimeout(() => cleanupTempFiles(merged), 1500)
  }

  async function mailTasks(list: any[]) {
    if (!confirmReasonDeleteBatch(list)) return
    const eligible = list.filter(t => t.document_uploads?.drive_url)
    if (!eligible.length) return
    const boat = eligible.filter(isBoatNoteTask)
    const others = eligible.filter(t => !isBoatNoteTask(t))
    let merged: TempMergedFile[] = []
    if (boat.length) {
      const m = await mergeBoatNoteTasks(boat)
      if (!m) return   // error already shown — nothing mailed, tasks stay
      merged = m
    }
    const attachments = [
      ...merged.map(f => ({ filename: f.fileName, url: f.driveLink })),
      ...others.map(t => ({ filename: t.document_uploads.file_name, url: t.document_uploads.drive_url })),
    ]
    const taskIds = eligible.map(t => t.id)
    const docIds = eligible.map(t => ({ id: t.document_uploads.id, ephemeral: isEphemeralReason(t.document_uploads) }))
    setTempFiles(merged.length ? merged : null)
    setEmailAttachments(attachments)
    setPendingMailActions({ taskIds, docIds })
    setEmailReason(boat.length
      ? { reason: TEMP_MERGE_SUBJECT, note: null }
      : { reason: eligible[0].document_uploads.reason ?? null, note: eligible[0].document_uploads.reason_note ?? null })
    setSelected({})
  }

  const downloadSelected = () => downloadTasks(selectedTasks)
  const mailSelected = () => mailTasks(selectedTasks)
  const printSelected = () => printTasks(selectedTasks)

  async function deleteTasks(ids: string[]) {
    if (!ids.length) return
    if (!confirm(`Delete ${ids.length} picked task record${ids.length === 1 ? '' : 's'}? This only removes the pick record — the document itself is not affected.`)) return
    setDeleting(true)
    try {
      await fetch(`/api/user-tasks?ids=${ids.join(',')}`, { method: 'DELETE', headers: await authHeader() })
      setTasks(prev => prev.filter(t => !ids.includes(t.id)))
      setSelected({})
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-semibold text-gray-900 text-sm flex items-center gap-2"><UserCheck size={16} className="text-green-600"/>My Picked Tasks</h2>
        {selectedTasks.length > 0 && (
          <div className="flex items-center gap-1.5">
            {merging && <span className="flex items-center gap-1 text-[11px] text-gray-400"><Loader size={11} className="animate-spin"/> Merging…</span>}
            <button onClick={downloadSelected} disabled={merging} className="flex items-center gap-1 px-2 py-1.5 rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 text-xs disabled:opacity-50">
              <Download size={12}/> ({selectedTasks.length})
            </button>
            <button onClick={mailSelected} disabled={merging} className="flex items-center gap-1 px-2 py-1.5 rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 text-xs disabled:opacity-50">
              <Mail size={12}/> ({selectedTasks.length})
            </button>
            <button onClick={printSelected} disabled={merging} className="flex items-center gap-1 px-2 py-1.5 rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 text-xs disabled:opacity-50" title="Print">
              <Printer size={12}/> ({selectedTasks.length})
            </button>
            <button onClick={returnSelected} disabled={bulkBusy}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs text-white disabled:opacity-50" style={{ background: '#ef4444' }}>
              {bulkBusy ? <Loader size={12} className="animate-spin"/> : <Undo2 size={12}/>} Resolve Selected
            </button>
            {isAdmin && (
              <button onClick={() => deleteTasks(selectedTasks.map(t => t.id))} disabled={deleting}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs text-white disabled:opacity-50" style={{ background: '#7f1d1d' }}>
                {deleting ? <Loader size={12} className="animate-spin"/> : <Trash2 size={12}/>} Delete Selected
              </button>
            )}
          </div>
        )}
      </div>
      {loading ? (
        <div className="flex justify-center py-8"><Loader size={18} className="animate-spin text-gray-400"/></div>
      ) : tasks.length === 0 ? (
        <p className="text-xs text-gray-400 text-center py-6">You haven't picked anything</p>
      ) : (
        <div className="space-y-1.5 max-h-80 overflow-y-auto">
          <button onClick={toggleAll} className="flex items-center gap-2 text-xs text-gray-400 hover:text-gray-600 px-0.5 pb-1">
            {allSelected ? <CheckSquare size={14} className="text-green-600"/> : <Square size={14}/>} Select all
          </button>
          {tasks.map(t => (
            <div key={t.id} className="flex items-center justify-between text-xs border border-gray-100 rounded-lg p-2.5">
              <div className="flex items-center gap-2 min-w-0">
                <button onClick={() => toggle(t.id)} className="flex-shrink-0 text-gray-300 hover:text-green-600">
                  {selected[t.id] ? <CheckSquare size={14} className="text-green-600"/> : <Square size={14}/>}
                </button>
                <div className="min-w-0">
                  <p className="font-medium text-gray-800 truncate flex items-center gap-1.5">
                    {t.document_uploads?.file_name}
                    <ReasonBadge reason={t.document_uploads?.reason} note={t.document_uploads?.reason_note}/>
                  </p>
                  <p className="text-gray-400">Picked {new Date(t.picked_at).toLocaleString('en-GB')}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                {t.document_uploads?.drive_url && (
                  <>
                    <button disabled={merging} onClick={() => {
                      if (isBoatNoteTask(t)) { downloadTasks([t]); return }
                      if (!confirmReasonDelete(t.document_uploads)) return
                      window.open(toDriveDownloadUrl(t.document_uploads.drive_url), '_blank')
                      logAction(t.document_uploads.id, 'download')
                      if (isEphemeralReason(t.document_uploads)) deleteReasonDoc(t.document_uploads.id)
                      setTasks(prev => prev.filter(x => x.id !== t.id))
                    }} className="flex items-center gap-1 px-2 py-1.5 rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-50">
                      <Download size={12}/>
                    </button>
                    <button disabled={merging} onClick={() => {
                      if (isBoatNoteTask(t)) { mailTasks([t]); return }
                      if (!confirmReasonDelete(t.document_uploads)) return
                      setEmailAttachments([{ filename: t.document_uploads.file_name, url: t.document_uploads.drive_url }])
                      setPendingMailActions({ taskIds: [t.id], docIds: [{ id: t.document_uploads.id, ephemeral: isEphemeralReason(t.document_uploads) }] })
                      setEmailReason({ reason: t.document_uploads.reason ?? null, note: t.document_uploads.reason_note ?? null })
                    }} className="flex items-center gap-1 px-2 py-1.5 rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-50">
                      <Mail size={12}/>
                    </button>
                    <button disabled={merging} onClick={() => printTasks([t])} className="flex items-center gap-1 px-2 py-1.5 rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-50" title="Print">
                      <Printer size={12}/>
                    </button>
                  </>
                )}
                <button onClick={() => handleReturn(t.id)} disabled={busyId === t.id}
                  className="flex items-center gap-1 px-2 py-1.5 rounded-md text-white disabled:opacity-50" style={{ background: '#ef4444' }}>
                  {busyId === t.id ? <Loader size={12} className="animate-spin"/> : <Undo2 size={12}/>} Resolve/Return
                </button>
                {isAdmin && (
                  <button onClick={() => deleteTasks([t.id])} disabled={deleting} className="text-gray-300 hover:text-red-500 disabled:opacity-50" title="Delete (admin)">
                    <Trash2 size={14}/>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
      {emailAttachments && (
        <EmailPdfModal
          attachments={emailAttachments}
          documentReason={emailReason?.reason}
          documentReasonNote={emailReason?.note}
          onClose={() => {
            // Closed without sending: the temporary merged files were never
            // used, so drop them (a later Mail simply rebuilds them).
            if (tempFiles) deleteTempFiles(tempFiles)
            setTempFiles(null); setEmailAttachments(null); setPendingMailActions(null); setEmailReason(null)
          }}
          onSent={() => {
            if (pendingMailActions) {
              const idSet = new Set(pendingMailActions.taskIds)
              for (const doc of pendingMailActions.docIds) {
                logAction(doc.id, 'mail')
                if (doc.ephemeral) deleteReasonDoc(doc.id)
              }
              setTasks(prev => prev.filter(t => !idSet.has(t.id)))
              setPendingMailActions(null)
            }
            if (tempFiles) {
              const files = tempFiles
              setTempFiles(null)
              setTimeout(() => cleanupTempFiles(files), 400)
            }
          }}
        />
      )}
    </div>
  )
}

// ── Admin/Overview "Pick History" audit log ───────────────────────────────
// One document = one row: who uploaded/notified/picked/returned/mailed/
// downloaded it, each cell showing the LATEST who+when (a return-then-
// re-pick cycle updates "Picked" in place rather than adding a new row).
// The full raw event list still exists per document — "View" opens it in a
// popup for the rare case someone needs the entire timeline, not just the
// latest state of each action.
interface HistoryEvent { action: string; user_name: string; user_id?: string; action_timestamp: string }
interface DocHistoryRow {
  document_id: string; file_name: string; doc_type: string; uploaded_by_name: string; uploaded_at: string
  reason?: string | null; reason_note?: string | null
  notify: HistoryEvent | null; pick: HistoryEvent | null; return: HistoryEvent | null
  mail: HistoryEvent | null; download: HistoryEvent | null; look: HistoryEvent | null
  history: HistoryEvent[]
}

function EventCell({ e }: { e: HistoryEvent | null }) {
  if (!e) return <span className="text-gray-300">—</span>
  return (
    <div>
      <p className="text-gray-700">{e.user_name || '—'}</p>
      <p className="text-gray-400 text-[10px]">{new Date(e.action_timestamp).toLocaleString('en-GB')}</p>
    </div>
  )
}

// ── Pending Final Document — CO/Phyto/SAFTA/any custom type sent with
// reason "Final Document" (SendModal). Picking is open to anyone, same
// model as Incoming — once picked, only that picker (or an admin, enforced
// server-side) can Reject (deletes the generated file + clears the saved
// link so it can be regenerated from scratch) or Done (uploads the scanned
// signed/stamped final PDF, which replaces the file at that same link).
function PendingFinalDocumentsPanel({ currentUserId, onCountChange }: { currentUserId: string; onCountChange?: (n: number) => void }) {
  const [tasks, setTasks] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)

  async function load(silent = false) {
    if (!silent) setLoading(true)
    try {
      const res = await fetch('/api/final-document-tasks', { headers: await authHeader() })
      const d = await res.json()
      if (res.ok) { setTasks(d.tasks || []); onCountChange?.((d.tasks || []).length) }
    } finally { if (!silent) setLoading(false) }
  }
  useEffect(() => {
    load()
    const t = setInterval(() => load(true), 15000)
    return () => clearInterval(t)
  }, [])

  async function act(taskId: string, body: Record<string, unknown>) {
    setBusyId(taskId)
    try {
      const res = await fetch('/api/final-document-tasks', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ task_id: taskId, ...body }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      await load()
    } catch (e: any) { alert(e.message) }
    finally { setBusyId(null) }
  }

  async function reject(taskId: string) {
    if (!confirm('Reject this document? The generated file will be deleted — it can be generated again from scratch after this.')) return
    await act(taskId, { action: 'reject' })
  }

  async function doneWithFile(task: any, file: File) {
    setBusyId(task.id)
    try {
      const base64 = await fileToBase64(file)
      const h = await authHeader()
      const upRes = await fetch('/api/upload-to-drive', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
        body: JSON.stringify({ base64, fileName: file.name, mimeType: file.type || 'application/pdf', docType: task.document_type }),
      })
      const upData = await upRes.json()
      if (!upRes.ok || !upData.driveLink) throw new Error(upData.error || 'Upload failed')
      const res = await fetch('/api/final-document-tasks', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
        body: JSON.stringify({ action: 'done', task_id: task.id, drive_url: upData.driveLink, file_name: file.name }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      await load()
    } catch (e: any) { alert(e.message) }
    finally { setBusyId(null) }
  }

  // Lets the picker swap the attached file on their own in-progress task
  // (wrong scan attached, etc.) without Reject reopening it to the whole pool.
  async function updateWithFile(task: any, file: File) {
    setBusyId(task.id)
    try {
      const base64 = await fileToBase64(file)
      const h = await authHeader()
      const upRes = await fetch('/api/upload-to-drive', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
        body: JSON.stringify({ base64, fileName: file.name, mimeType: file.type || 'application/pdf', docType: task.document_type }),
      })
      const upData = await upRes.json()
      if (!upRes.ok || !upData.driveLink) throw new Error(upData.error || 'Upload failed')
      const res = await fetch('/api/final-document-tasks', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...h },
        body: JSON.stringify({ action: 'update', task_id: task.id, drive_url: upData.driveLink, file_name: file.name }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error)
      await load()
    } catch (e: any) { alert(e.message) }
    finally { setBusyId(null) }
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-semibold text-gray-900 text-sm flex items-center gap-2">
          <FileCheck size={15} className="text-green-600"/> Pending Final Document
          {tasks.length > 0 && <span className="text-[11px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded-full font-bold">{tasks.length}</span>}
        </h2>
        {loading && <Loader size={13} className="animate-spin text-gray-400"/>}
      </div>
      {tasks.length === 0 ? (
        <p className="text-xs text-gray-400 text-center py-6">No pending final documents</p>
      ) : (
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {tasks.map(t => {
            const pickedByMe = t.status === 'picked' && t.picked_by === currentUserId
            const pickedByOther = t.status === 'picked' && t.picked_by !== currentUserId
            const busy = busyId === t.id
            return (
              <div key={t.id} className="border border-gray-100 rounded-lg p-2.5">
                <div className="flex items-center justify-between mb-1.5 gap-2">
                  <span className="text-xs font-semibold text-gray-800">CUSDEC {t.cusdec_number || '—'} · {docTypeLabel(t.document_type)}</span>
                  <a href={t.drive_url} target="_blank" rel="noreferrer" className="text-[11px] text-blue-600 hover:underline flex-shrink-0">View</a>
                </div>
                {t.status === 'pending' && (
                  <button onClick={() => act(t.id, { action: 'pick' })} disabled={busy}
                    className="btn-secondary text-xs w-full flex items-center justify-center gap-1.5 disabled:opacity-50">
                    {busy ? <Loader size={12} className="animate-spin"/> : <UserCheck size={12}/>} Pick
                  </button>
                )}
                {pickedByOther && <p className="text-[11px] text-gray-400">Picked by {t.picked_by_name || '—'}</p>}
                {pickedByMe && (
                  <div className="space-y-1.5">
                    <div className="flex gap-1.5">
                      <button onClick={() => reject(t.id)} disabled={busy}
                        className="flex-1 text-xs py-1.5 rounded-md border border-red-200 text-red-600 hover:bg-red-50 disabled:opacity-50">
                        Reject
                      </button>
                      <label className={`flex-1 text-xs py-1.5 rounded-md text-white text-center font-medium ${busy ? 'bg-gray-300' : 'bg-green-600 hover:bg-green-700 cursor-pointer'}`}>
                        {busy ? 'Working…' : 'Done — Upload Scan'}
                        <input type="file" accept="application/pdf" className="hidden" disabled={busy}
                          onChange={e => { const f = e.target.files?.[0]; if (f) doneWithFile(t, f); e.target.value = '' }}/>
                      </label>
                    </div>
                    <label className={`block text-xs py-1.5 rounded-md text-center font-medium border ${busy ? 'border-gray-200 text-gray-300' : 'border-gray-200 text-gray-600 hover:bg-gray-50 cursor-pointer'}`}
                      title="Replace the attached file on this in-progress task without rejecting it back to the pool">
                      {busy ? 'Working…' : 'Update — Replace File'}
                      <input type="file" accept="application/pdf" className="hidden" disabled={busy}
                        onChange={e => { const f = e.target.files?.[0]; if (f) updateWithFile(t, f); e.target.value = '' }}/>
                    </label>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

// "Not Complete Shipment" shows every green (export_release_passed) CUSDEC
// that hasn't been marked shipment_complete yet; "Not Payment Complete
// Shipment" shows every shipment_complete CUSDEC that hasn't been marked
// payment_complete yet (payment only makes sense once the shipment itself
// is done) — same panel shape, different column/filter, so one component
// covers both via `mode`.
function ShipmentCompletionPanel({ mode, onCountChange }: { mode: 'shipment' | 'payment'; onCountChange?: (n: number) => void }) {
  const [rows, setRows] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)
  const doneCol = mode === 'shipment' ? 'shipment_complete' : 'payment_complete'
  const doneAtCol = mode === 'shipment' ? 'shipment_complete_at' : 'payment_complete_at'
  const title = mode === 'shipment' ? 'Not Complete Shipment' : 'Not Payment Complete Shipment'

  async function load(silent = false) {
    if (!silent) setLoading(true)
    try {
      const res = await fetch('/api/list-records?table=cusdec&limit=500', { headers: await authHeader() })
      const d = await res.json()
      const filtered = (d.records || []).filter((c: any) =>
        mode === 'shipment' ? (c.export_release_passed && !c.shipment_complete) : (c.shipment_complete && !c.payment_complete)
      )
      setRows(filtered)
      onCountChange?.(filtered.length)
    } finally {
      if (!silent) setLoading(false)
    }
  }

  useEffect(() => {
    load()
    const t = setInterval(() => load(true), 20000)
    return () => clearInterval(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode])

  async function markDone(id: string) {
    setBusyId(id)
    try {
      const res = await fetch('/api/admin-data', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ table: 'cusdec', id, updates: { [doneCol]: true, [doneAtCol]: new Date().toISOString() } }),
      })
      if (res.ok) setRows(prev => { const next = prev.filter(r => r.id !== id); onCountChange?.(next.length); return next })
    } finally {
      setBusyId(null)
    }
  }

  return (
    <div className="card">
      <h2 className="font-semibold text-gray-900 mb-3 text-sm">{title}</h2>
      {loading ? (
        <div className="flex justify-center py-8"><Loader size={18} className="animate-spin text-gray-400"/></div>
      ) : rows.length === 0 ? (
        <p className="text-xs text-gray-400 py-4 text-center">None pending</p>
      ) : (
        <div className="space-y-1.5 max-h-96 overflow-y-auto">
          {rows.map(r => (
            <div key={r.id} className="flex items-center justify-between text-xs border border-gray-100 rounded-lg p-2.5">
              <div className="min-w-0">
                <p className="font-medium text-gray-800">CUSDEC {r.code} {r.number} <span className="text-gray-400 font-normal">· {r.exporter}</span></p>
                <p className="text-gray-400">
                  {r.reference && <>Ref: <span className="text-gray-600">{r.reference}</span> · </>}
                  CAP: {r.cap || '—'} · Created: {r.created_at ? new Date(r.created_at).toLocaleDateString('en-GB') : '—'}
                </p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                {r.reference && (
                  <a href={`/admin/shipment-overview?reference=${encodeURIComponent(r.reference)}`} className="text-blue-600 hover:underline">View →</a>
                )}
                <button onClick={() => markDone(r.id)} disabled={busyId === r.id}
                  className="flex items-center gap-1 px-2 py-1.5 rounded-md text-white disabled:opacity-50" style={{ background: '#22A87A' }}>
                  {busyId === r.id ? <Loader size={12} className="animate-spin"/> : <Check size={12}/>} Done
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function PickHistoryPanel() {
  const { isAdmin } = usePermission()
  // Deliberately not grantable via allowed_tabs (unlike every other
  // section:* permission) — bulk-purging the audit log itself should stay
  // admin-only, not something an admin can hand off to a regular user.
  const canDelete = isAdmin
  const [items, setItems] = useState<DocHistoryRow[]>([])
  const [loading, setLoading] = useState(false)
  const [fileName, setFileName] = useState('')
  const [user, setUser] = useState('')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [reason, setReason] = useState('')
  const [selected, setSelected] = useState<Record<string, boolean>>({})
  const [clearing, setClearing] = useState(false)
  const [viewing, setViewing] = useState<DocHistoryRow | null>(null)

  async function load(silent = false, targetPage = page) {
    if (!silent) setLoading(true)
    try {
      const params = new URLSearchParams()
      if (fileName) params.set('fileName', fileName)
      if (user) params.set('user', user)
      if (reason) params.set('reason', reason)
      params.set('page', String(targetPage))
      const res = await fetch(`/api/pick-history?${params.toString()}`, { headers: await authHeader() })
      const d = await res.json()
      if (res.ok) { setItems(d.items || []); setTotalPages(d.totalPages || 1) }
    } finally { if (!silent) setLoading(false) }
  }
  useEffect(() => { load(false, 1); setPage(1) }, []) // eslint-disable-line react-hooks/exhaustive-deps
  // Live updates — same polling approach as Incoming, so a new pick/return/
  // mail/download shows up here without a manual Search click.
  useEffect(() => {
    const t = setInterval(() => load(true), 8000)
    return () => clearInterval(t)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  function goToPage(p: number) {
    const clamped = Math.max(1, Math.min(totalPages, p))
    setPage(clamped)
    load(false, clamped)
  }

  async function remove(documentId: string) {
    if (!confirm('Delete this Processed History entry? This only clears the history log — the uploaded file and its data are not affected.')) return
    const res = await fetch(`/api/pick-history?document_id=${documentId}`, { method: 'DELETE', headers: await authHeader() })
    if (res.ok) setItems(prev => prev.filter(i => i.document_id !== documentId))
    else { const d = await res.json().catch(() => ({})); alert(d.error || 'Delete failed') }
  }

  // Safety net for Download removing a task before the file actually
  // finished saving (no browser event exists to tell the two apart) —
  // puts it back into whoever downloaded/mailed it's My Picked Tasks.
  async function restoreToPicked(row: DocHistoryRow) {
    const source = row.download || row.mail || row.pick
    if (!source?.user_id) { alert('No user on record for this action — cannot restore.'); return }
    if (!confirm(`Restore "${row.file_name}" to ${source.user_name}'s My Picked Tasks?`)) return
    const res = await fetch('/api/pick-history', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
      body: JSON.stringify({ action: 'restore', document_id: row.document_id, user_id: source.user_id, user_name: source.user_name }),
    })
    const d = await res.json()
    if (!res.ok) { alert(d.error || 'Restore failed'); return }
    // The restore inserts a fresh pick_history_log row server-side — reload
    // now instead of waiting for the 8s poll so the new "Picked" entry (and
    // the fact it's active again) shows immediately.
    load(false, page)
  }

  // Reverse — one step back through Notify → Pick → Mail/Download →
  // Approved, whichever one this document is currently at. The server
  // (reverse-document.ts) figures out which step that is; here it's just
  // "click, it moves back one, reload". Locked/reserved items and anything
  // already at Active Log come back as an error, shown as-is.
  const [reversingId, setReversingId] = useState<string | null>(null)
  async function reverseOneStep(documentId: string) {
    if (!confirm('Reverse this document one step (undoing the most recent Notify/Pick/Mail/Download/Approve stage)?')) return
    setReversingId(documentId)
    try {
      const res = await fetch('/api/reverse-document', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ document_id: documentId, mode: 'step' }),
      })
      const d = await res.json()
      if (!res.ok) { alert(d.error || 'Reverse failed'); return }
      load(false, page)
    } finally {
      setReversingId(null)
    }
  }

  // Full Delete — separate from the plain "Delete" above (which only ever
  // clears the log line, on purpose). This one actually removes the Drive
  // file + the structured-table row, cascading the same way the Database
  // page does (CUSDEC → its CDNs → their barcode/boat note) — the server
  // first reports back everything that would go, so the confirm here can
  // list it, and only deletes for real once confirmed.
  const [fullDeleting, setFullDeleting] = useState<string | null>(null)
  async function fullDelete(documentId: string) {
    setFullDeleting(documentId)
    try {
      const preview = await fetch('/api/reverse-document', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ document_id: documentId, mode: 'full-delete' }),
      })
      const p = await preview.json()
      if (!preview.ok) { alert(p.error || 'Could not check what this would affect'); return }
      const list = (p.files || []).join('\n- ')
      const ok = confirm(`This will permanently remove ${p.count} file${p.count === 1 ? '' : 's'} from Drive and the database:\n- ${list}\n\nThis goes to the Recycle Bin first (an admin can restore it from there), but is otherwise final. Continue?`)
      if (!ok) return
      const res = await fetch('/api/reverse-document', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
        body: JSON.stringify({ document_id: documentId, mode: 'full-delete', confirmed: true }),
      })
      const d = await res.json()
      if (!res.ok) { alert(d.error || 'Delete failed'); return }
      setItems(prev => prev.filter(i => i.document_id !== documentId))
    } finally {
      setFullDeleting(null)
    }
  }

  function toggle(id: string) { setSelected(prev => ({ ...prev, [id]: !prev[id] })) }
  const selectedIds = Object.keys(selected).filter(id => selected[id])
  const allSelected = items.length > 0 && selectedIds.length === items.length
  function toggleAll() { setSelected(allSelected ? {} : Object.fromEntries(items.map(i => [i.document_id, true]))) }

  // Admin-only bulk purge — only ever removes pick_history_log rows (and
  // their audit copy in deleted_records, same as the single-delete path).
  // The uploaded file, its Drive copy, and the extracted data in the
  // doc-type table are never touched — strictly the audit trail.
  async function clearSelected() {
    if (!confirm(`Delete ${selectedIds.length} Processed History entr${selectedIds.length === 1 ? 'y' : 'ies'}? This only clears the history log — uploaded files and extracted data are not affected.`)) return
    setClearing(true)
    for (const id of selectedIds) {
      try { await fetch(`/api/pick-history?document_id=${id}`, { method: 'DELETE', headers: await authHeader() }) } catch {}
    }
    setSelected({})
    setClearing(false)
    load()
  }

  return (
    <div className="card mt-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-semibold text-gray-900 text-sm flex items-center gap-2"><History size={16} className="text-gray-500"/>Processed History</h2>
        {canDelete && selectedIds.length > 0 && (
          <button onClick={clearSelected} disabled={clearing}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs text-white disabled:opacity-50" style={{ background: '#ef4444' }}>
            {clearing ? <Loader size={12} className="animate-spin"/> : <Trash2 size={12}/>} Delete Selected ({selectedIds.length})
          </button>
        )}
      </div>
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <input value={fileName} onChange={e => setFileName(e.target.value)} placeholder="File name..." className="input max-w-[160px]"/>
        <input value={user} onChange={e => setUser(e.target.value)} placeholder="User..." className="input max-w-[140px]"/>
        <select value={reason} onChange={e => setReason(e.target.value)} className="input max-w-[150px]">
          <option value="">All reasons</option>
          <option value="CUSDEC Passed">CUSDEC Passed</option>
          <option value="Container Moved">Container Moved</option>
          <option value="Boat Note Passed">Boat Note Passed</option>
          <option value="Final Document">Final Document</option>
          <option value="Other">Other</option>
        </select>
        <button onClick={() => { setPage(1); load(false, 1) }} className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs text-white" style={{ background: '#1B3A5C' }}>
          <Search size={12}/> Search
        </button>
      </div>
      {loading ? (
        <div className="flex justify-center py-8"><Loader size={18} className="animate-spin text-gray-400"/></div>
      ) : items.length === 0 ? (
        <p className="text-xs text-gray-400 text-center py-6">No history yet</p>
      ) : (
        <>
        <div className="overflow-x-auto max-h-[28rem] overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="bg-gray-50 sticky top-0"><tr>
              {(canDelete ? [''] : []).concat(['File', 'Uploaded', 'Notified', 'Picked', 'Mailed', 'Downloaded']).concat(['']).map((h, i) => (
                <th key={h || `h${i}`} className="text-left px-2 py-1.5 text-gray-500 font-medium whitespace-nowrap">
                  {canDelete && i === 0 ? (
                    <button onClick={toggleAll} className="text-gray-400 hover:text-gray-600">
                      {allSelected ? <CheckSquare size={13} className="text-green-600"/> : <Square size={13}/>}
                    </button>
                  ) : h}
                </th>
              ))}
            </tr></thead>
            <tbody>
              {items.map(row => (
                <tr key={row.document_id} className="border-t border-gray-50 align-top">
                  {canDelete && (
                    <td className="px-2 py-1.5">
                      <button onClick={() => toggle(row.document_id)} className="text-gray-300 hover:text-green-600">
                        {selected[row.document_id] ? <CheckSquare size={13} className="text-green-600"/> : <Square size={13}/>}
                      </button>
                    </td>
                  )}
                  <td className="px-2 py-1.5 text-gray-800 max-w-[160px]">
                    <span className="truncate block">{row.file_name || '—'}</span>
                    <ReasonBadge reason={row.reason} note={row.reason_note}/>
                  </td>
                  <td className="px-2 py-1.5"><EventCell e={{ action: 'upload', user_name: row.uploaded_by_name, action_timestamp: row.uploaded_at }}/></td>
                  <td className="px-2 py-1.5"><EventCell e={row.notify}/></td>
                  <td className="px-2 py-1.5">
                    <EventCell e={row.pick}/>
                    {row.return && row.return.action_timestamp > (row.pick?.action_timestamp || '') && (
                      <p className="text-amber-500 text-[10px] mt-0.5">Returned — back in pool</p>
                    )}
                  </td>
                  <td className="px-2 py-1.5"><EventCell e={row.mail}/></td>
                  <td className="px-2 py-1.5"><EventCell e={row.download}/></td>
                  <td className="px-2 py-1.5 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <button onClick={() => setViewing(row)} className="text-gray-400 hover:text-gray-600" title="View full history"><Eye size={13}/></button>
                      {canDelete && (row.download || row.mail) && (
                        <button onClick={() => restoreToPicked(row)} className="text-blue-400 hover:text-blue-600" title="Restore to Picked Tasks">
                          <UserCheck size={13}/>
                        </button>
                      )}
                      {canDelete && (
                        <button onClick={() => reverseOneStep(row.document_id)} disabled={reversingId === row.document_id}
                          className="text-amber-500 hover:text-amber-700 disabled:opacity-40" title="Reverse one step (undo the latest Notify/Pick/Mail/Download/Approve)">
                          {reversingId === row.document_id ? <Loader size={12} className="animate-spin"/> : <Undo2 size={13}/>}
                        </button>
                      )}
                      {canDelete && (
                        <button onClick={() => remove(row.document_id)} className="text-red-400 hover:text-red-600" title="Delete (history log only — file and data untouched)">
                          <Trash2 size={12}/>
                        </button>
                      )}
                      {canDelete && (
                        <button onClick={() => fullDelete(row.document_id)} disabled={fullDeleting === row.document_id}
                          className="text-red-700 hover:text-red-900 disabled:opacity-40" title="Full Delete — removes the Drive file + database row too (and anything under the same CUSDEC/CDN)">
                          {fullDeleting === row.document_id ? <Loader size={12} className="animate-spin"/> : <Trash2 size={13} strokeWidth={2.75}/>}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-3 mt-3 text-xs text-gray-500">
            <button onClick={() => goToPage(page - 1)} disabled={page <= 1} className="disabled:opacity-30 hover:text-gray-800">Prev</button>
            <span>Page {page} / {totalPages}</span>
            <button onClick={() => goToPage(page + 1)} disabled={page >= totalPages} className="disabled:opacity-30 hover:text-gray-800">Next</button>
          </div>
        )}
        </>
      )}

      {viewing && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setViewing(null)}>
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-4 border-b">
              <p className="font-semibold text-sm truncate">{viewing.file_name}</p>
              <button onClick={() => setViewing(null)} className="text-gray-400 hover:text-gray-700">✕</button>
            </div>
            <div className="p-4 overflow-y-auto flex-1 space-y-2">
              <div className="text-xs border border-gray-100 rounded-lg p-2.5">
                <p className="font-medium text-gray-700 capitalize">upload</p>
                <p className="text-gray-500">{viewing.uploaded_by_name || '—'}</p>
                <p className="text-gray-400">{new Date(viewing.uploaded_at).toLocaleString('en-GB')}</p>
              </div>
              {viewing.history.map((e, i) => (
                <div key={i} className="text-xs border border-gray-100 rounded-lg p-2.5">
                  <p className="font-medium text-gray-700 capitalize">{e.action}</p>
                  <p className="text-gray-500">{e.user_name || '—'}</p>
                  <p className="text-gray-400">{new Date(e.action_timestamp).toLocaleString('en-GB')}</p>
                </div>
              ))}
              {viewing.history.length === 0 && <p className="text-xs text-gray-400 text-center py-4">No further activity yet</p>}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}